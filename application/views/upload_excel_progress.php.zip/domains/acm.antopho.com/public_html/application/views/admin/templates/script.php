<script src="<?php echo base_url('assets/admin'); ?>/js/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/js/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/select2/select2.full.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/js/adminlte.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/fullcalendar/main.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/moment/moment.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/jszip/jszip.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/css/datatables-buttons/js/buttons.colVis.min.js"></script>
<script src="<?php echo base_url('assets/admin'); ?>/js/tinymce/js/tinymce/tinymce.min.js"></script>
<script>
    var $stickyHeight = 250;
    var $padding = 20;
    var $topOffset = 1400;
    var $footerHeight = 10;
    /* <![CDATA[ */
    function scrollSticky() {
        if ($(window).height() >= $stickyHeight) {
            var aOffset = $('#sticky').offset();
            if ($(document).height() - $footerHeight - $padding < $(window).scrollTop() + $stickyHeight) {
                var $top = $(document).height() - $stickyHeight - $footerHeight - $padding - 185;
                $('#sticky').attr('style', 'position:absolute; top:' + $top + 'px;');
            } else if ($(window).scrollTop() + $padding > $topOffset) {
                $('#sticky').attr('style', 'position:fixed; top:' + $padding + 'px;');
            } else {
                $('#sticky').attr('style', 'position:relative;');
            }
        }
    }
    $(window).scroll(function() {
        scrollSticky();
    });
    /* ]]> */
</script>
<script>
    $(function() {
        //Check SEO      
        $("#meta_title").on({
            keyup: function() {
                checkSEO();
            }
        });
        $("#meta_description").on({
            keyup: function() {
                checkSEO();
            }
        });
        //Check SEO End

        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
        tinymce.init({
            selector: 'textarea.tinymce-field',
            plugins: 'print preview paste importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap emoticons',
            toolbar: 'undo redo removeformat | link image | bold italic underline strikethrough | fullscreen numlist bullist',
            image_title: true,
            height: 400,
            toolbar_mode: 'warp',
            language: 'vi',

        });
        tinymce.init({
            selector: 'textarea.tinymce-field-content',
            plugins: 'print preview paste importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists wordcount imagetools textpattern noneditable help charmap emoticons',
            toolbar: 'undo redo removeformat | fontfamily fontsize blocks | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | image media fullscreen link |  numlist bullist | forecolor backcolor | pagebreak | charmap  |  preview save |  outdent indent',
            content_style: "body {font-size: 14pt;}",
            height: 1000,
            toolbar_sticky: true,
            toolbar_mode: 'sliding',
            language: 'vi',
            image_title: true,
            entity_encoding: "raw",

            init_instance_callback: function(editor) {
                editor.on('keyup', function(e) {
                    checkSEO();
                    var id = $('#id_update').val();
                    var content = tinymce.get("meta_content").getContent();

                    $.ajax({
                        type: 'POST',
                        url: "<?= base_url('keyword/auto-update'); ?>",
                        data: {
                            "ID": id,
                            "content": content
                        },
                        success: function() {}
                    });
                });
            }
        });

        // Summernote
        $('#summernote').summernote({
            height: 400
        })

        $('#summernote1').summernote({
            height: 150
        })

        $("#paydatatables").DataTable({
            "responsive": true,
            "autoWidth": false,
            order: [
                [7, 'desc']
            ],
            pagingType: 'full_numbers',
            "pageLength": 50,
            "buttons": ["excel"]
        }).buttons().container().appendTo('#paydatatables_wrapper .col-md-6:eq(0)');

        $('.datatables').DataTable({
            "responsive": true,
            "autoWidth": false,
            order: [
                [0, 'desc']
            ],
            pagingType: 'full_numbers',
            "pageLength": 50
        });

    })

    function checkSEO() {
        var countError = 0;
        var keyword = $('#keyword_seo').html();
        let keywordLowerCase = keyword.toLowerCase();

        var title = $('#meta_title').val();
        let titleLowerCase = title.toLowerCase();

        var description = $('#meta_description').val();
        let descriptionLowerCase = description.toLowerCase();

        var content = tinymce.get("meta_content").getContent();
        let contentLowerCase = content.toLowerCase();

        //Dom
        let domParser = new DOMParser();
        let doc = domParser.parseFromString(contentLowerCase, "text/html");
        let contentH2 = doc.getElementsByTagName("h2");
        var contentH2Arr = Array.prototype.slice.call(contentH2);
        let resultHeading = false;

        contentH2Arr.forEach((element) => {

            let eachResultHeading = element.outerText.includes(keywordLowerCase);
            if (eachResultHeading == true) {
                resultHeading = true;
            }
        });

        let resultTitle = titleLowerCase.includes(keywordLowerCase);
        let resultDescription = descriptionLowerCase.includes(keywordLowerCase);
        let resultContent = contentLowerCase.includes(keywordLowerCase);

        if (resultTitle == false) {
            $('#meta_title_result').html('<span style="color:red;">Chưa có từ khóa trong Meta Title</span>');
            countError += 1;
        } else {
            $('#meta_title_result').html('<span style="color:green;">Đã có từ khóa trong Meta Title</span>');
        }
        if (resultDescription == false) {
            $('#meta_description_result').html('<span style="color:red;">Chưa có từ khóa trong Meta Description</span>');
            countError += 1;
        } else {
            $('#meta_description_result').html('<span style="color:green;">Đã có từ khóa trong Meta Description</span>');
        }
        if (resultContent == false) {
            $('#meta_content_result').html('<span style="color:red;">Chưa có từ khóa trong content</span>');
            countError += 1;
        } else {
            $('#meta_content_result').html('<span style="color:green;">Đã có từ khóa trong content</span>');
        }
        if (resultHeading == false) {
            $('#meta_heading_result').html('<span style="color:red;">Chưa có từ khóa trong Heading</span>');
            countError += 1;
        } else {
            $('#meta_heading_result').html('<span style="color:green;">Đã có từ khóa trong Heading</span>');
        }
        $('#count_error').html(countError);
    }

    function chonCtv() {
        var id = $('#filter-ctv').val();
        window.location.href = "<?= base_url('ctv_timeline?ctv_id='); ?>" + id;
    }

    function chonproject() {
        var id = $('#filter-project').val();
        var check_page = $('.check_page').val();
        var url = "<?= base_url(); ?>";
        window.location.href = url + check_page + "?project_id=" + id;
    }

    function metaLength(field) {
        var text = $('#meta_' + field).val();
        $('#post_update_' + field).html(text.length);
    }

    function projectRemoveCTV(project, ctv) {
        $.ajax({
            type: 'POST',
            url: "<?= base_url('project/delete_ctv'); ?>",
            data: {
                "project": project,
                "ctv": ctv
            },
            success: function() {
                alert('Xóa thành công');
                $("#project" + project + "removeCTV" + ctv).hide("slow");
            }
        });
    }
</script>
<?php if ($file == 'ctv_timeline') : ?>
    <script>
        $(function() {

            /* initialize the calendar
             -----------------------------------------------------------------*/
            //Date for the calendar events (dummy data)
            var date = new Date()
            var d = date.getDate(),
                m = date.getMonth(),
                y = date.getFullYear()

            var Calendar = FullCalendar.Calendar;
            var Draggable = FullCalendar.Draggable;

            var calendarEl = document.getElementById('calendar');

            // initialize the external events
            // -----------------------------------------------------------------



            var calendar = new Calendar(calendarEl, {
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay'
                },
                eventLimit: true,
                themeSystem: 'bootstrap',
                dayMaxEvents: 5,
                //Random default events
                events: <?= $timeline_js_array ?>
            });

            calendar.render();
            $('#calendar').fullCalendar()

        })
    </script>
<?php endif ?>