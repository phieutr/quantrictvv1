<?php
 $preview_id = $this->input->get('');
function customer_note_modal($keyword)
{
    return '
    <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#customer_note' . $keyword['ID'] . '">
    <i class="fa-solid fa-note"></i>
        </i>
        Khách góp ý
    </a>
    <div class="modal fade" id="customer_note' . $keyword['ID'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Góp ý bài viết #' . $keyword['ID'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="' . base_url('keyword/customer-note') . '">
                    <input type="hidden" name="ID" value="' . $keyword['ID'] . '">
                    <div class="form-group">
                        <label for="note">Nội dung góp ý</label>
                        <textarea type="text" class="form-control tinymce-field" name="customer_note" >' . $keyword['customer_note'] . '</textarea>
                    </div>                    
                    <button type="submit" class="btn btn-primary">Góp ý</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}
function point_modal($keyword)
{
    return '
    <a type="button" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#point' . $keyword['ID'] . '">
    <i class="fa-solid fa-note"></i>
        </i>
        Điểm
    </a>
    <div class="modal fade" id="point' . $keyword['ID'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Chấm điểm bài viết #' . $keyword['ID'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="' . base_url('keyword/point') . '">
                    <input type="hidden" name="ID" value="' . $keyword['ID'] . '">
                    <div class="form-group">
                        <label for="point">Chấm điểm</label>
                        <input type="number" class="form-control" name="point" value="' . $keyword['point'] . '">
                    </div>                    
                    <button type="submit" class="btn btn-primary">Chấm điểm</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}

function update_modal($keyword)
{
    return '<a target="_blank" class="btn btn-primary btn-sm" href="' . base_url('post/update/') . $keyword['ID'] . '">
<i class="fas fa-pencil-alt"></i>
    Update
</a>';
}
function delete_button($keyword)
{
    return '<a class="btn btn-danger btn-sm" href="' . base_url('keyword/delete?ID=') . $keyword['ID'] . '" onclick="return confirm(\'Xác nhận xóa?\')">
    <i class="fas fa-trash"></i>
        Xóa
    </a>';
}

$status_text = '';
$status_color = 'badge-secondary';

$button_approve         = false;
$button_approve_action  = '';
$button_approve_text    = '';
$button_approve_html    = '';

$button_point_html      = '';
$button_customer_note_html       = '';
$button_update_html     = update_modal($keyword);
$button_delete_html     = delete_button($keyword);

//Trạng thái
if ($keyword['outline_check'] == 0) {
    switch ($keyword['finish']) {
        case 0:
            $status_text = 'Đang viết';
            break;
        case 1:
            $status_text = 'Hoàn thành, Đã thanh toán';
            $status_color = 'badge-success';
            break;
        case 2:
            $status_text = 'Chờ duyệt';
            $status_color = 'badge-info';

            $button_approve         = true;
            $button_action          = 'content';
            $button_approve_text    = 'Duyệt';
            break;
        case 3:
            $status_text = 'Đã duyệt, chờ thanh toán';
            $status_color = 'badge-warning';

            $button_approve         = true;
            $button_action          = 'pay';
            $button_approve_text    = 'Thanh toán';
            break;
        case 4:
            $button_approve         = true;
            $button_action          = 'content';
            $button_approve_text    = 'Duyệt';
            $status_text = 'Có góp ý';
            $status_color = 'badge-danger';
            break;
    }
} else {
    if ($keyword['finish_outline'] == 1) {
        switch ($keyword['finish']) {
            case 0:
                $status_text = 'Đã duyệt outline, Đang viết';
                break;
            case 1:
                $status_text = 'Hoàn thành, Đã thanh toán';
                $status_color = 'badge-success';
                break;
            case 2:
                $status_text = 'Chờ duyệt';
                $status_color = 'badge-info';

                $button_approve         = true;
                $button_action          = 'content';
                $button_approve_text    = 'Duyệt';
                break;
            case 3:
                $status_text = 'Đã duyệt, chờ thanh toán';
                $status_color = 'badge-warning';

                $button_approve         = true;
                $button_action          = 'pay';
                $button_approve_text    = 'Thanh toán';
                break;
            case 4:
                $button_approve         = true;
                $button_action          = 'content';
                $button_approve_text    = 'Duyệt';
                $status_text = 'Có góp ý';
                $status_color = 'badge-danger';
                break;
        }
    } else {
        switch ($keyword['finish_outline']) {
            case 0:
                $status_text = 'Đang viết outline';
                break;
            case 2:
                $status_text    = 'Chờ duyệt outline';
                $status_color   = 'badge-info';

                $button_approve         = true;
                $button_action          = 'outline';
                $button_approve_text    = 'Duyệt outline';
                break;
        }
        if ($keyword['finish'] == 4) {
            $button_approve         = true;
            $button_action          = 'content';
            $button_approve_text    = 'Duyệt';
            $status_text = 'Có góp ý outline';
            $status_color = 'badge-danger';
        }
    }
}

//Nút duyệt
if ($button_approve == true) {
    $button_approve_html = '
    <a class="btn btn-success btn-sm" href="' . base_url('keyword/approve?ID=' . $keyword['ID'] . '&action=' . $button_action) . '"><i class="fa-solid fa-circle-check"></i>' . $button_approve_text . '</a>';
}
//Chấm điểm CTV
if ($keyword['finish'] == 1) {
    $button_point_html = point_modal($keyword);
}

if ($role != 'admin') {
    $button_point_html = '';
    $button_approve_html = '';
    $button_delete_html = '';
}

if ($role == 'customer') {
    $button_update_html = '';
    $button_customer_note_html       = customer_note_modal($keyword);
}

$ctv_info = row_select('users', ['ID' => $keyword['ctv']], ['username', 'phone', 'fullname']);
$thisCTV = $ctv_info['fullname'];

$price = null;
$price_array = row_select('keyword_type_price', ['keyword_type_id' => $keyword['keyword_type'], 'word' => $keyword['word']], ['price']);
if (empty($price_array)) {
    $price = '<small style="color:red;">Chưa có mức nhuận cho số từ này</small>';
} else {
    $price = number_format($price_array['price']);
}
$thisProject = row_select('project', ['ID' => $keyword['project']], ['name'])['name'];
$result_select_html = '<option value="0" selected>'.$thisProject.'</option>';
    if (empty($thisProject)) {
        $result_select_html = '<p style="color:red;">Không tồn tại hoặc đã xóa</p>';
    }else{
        $result_select = result_select('project',[], []);
        foreach ($result_select as $key => $value){
         $result_select_html .= '<option value="' . $value['ID'] . '">' . $value['name'] . '</option>';
    }}
?> 
   
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div style="background-color: #fff; padding: 30px; box-shadow: 0 0 1px rgb(0 0 0 / 13%), 0 1px 3px rgb(0 0 0 / 20%);border-radius: 0.25rem;" class="col-8">
                <a style="font-weight: 700; font-size: 16px;"> Meta Title: </a> <?= $keyword['metaTitle']; ?>
                <br>
                <a style="font-weight: 700;font-size: 16px;"> Meta Description: </a> <?= $keyword['metaDescription']; ?>
                <hr>

                <?= $keyword['content'] ?>
            </div>
            <div class="col-4">
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Thông tin bài viết</h3>
                    </div>
                    <div class="card-body table-responsive ">
                        <table class="table table-striped table-bordered table-valign-middle">
                            <tbody>
                                <tr>
                                    <td>Dự án</td>
                                     <td>
                                        <?php  if($role == 'admin'){ ?>
                                              <form method="post" style="margin-top:11%" action="<?= base_url('keyword/Update_result_select')?>">  
                                      <select class="form-control" name="result_select" style=" width: 312px" required>
                                        <?= $result_select_html ?>
                                     </select>
                                     <input type="hidden" name="check_result_select" value="<?= $keyword['ID'] ?>">
                                     <button type="submit" class="btn btn-primar" style="color:#007bff">Cập nhật</button>
                                       </form>
                                     <?php }else{?>
                                         <?= $thisProject ?>
                                        <?php } ?>
                                    </td>   
                                </tr>
                                <tr>
                                    <td>Số từ hiện tại/yêu cầu</td>
                                   
                                    <td><?= str_word_count(convert_name(strip_tags(html_entity_decode($keyword['content'])))); ?>/<a href="#boxnoidung" aria-expanded="false" data-toggle="collapse"><?= $keyword['word']; ?></a>
                                 
                                    <div class="collapse mt-4" id="boxnoidung">
                                     <form method="post" action="<?= base_url('keyword/Update_word') ?>">
                                    <input type="text" class="form-control" id="word" name="word" value="<?= $keyword['word']; ?>">
                                     <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                     <button type="submit" class="btn btn-primary">Cập nhật</button></td>
                                     </form>
                                         </div>
                                </tr>
                                <tr>
                                    <td>Trạng thái</td>
                                    <td><span class="badge <?= $status_color ?>"><?= $status_text ?></span>
                                   
                                <?php
                   $posted = result_select('keyword',[], []);
            foreach ($posted as $key => $value){
                if($value['ID'] == $keyword['ID']){
                    if($value['posted'] == 1){
                         $posted_color = 'posted_color';
                         $posted_text  =   'Đã đăng';
                    }else{
                         $posted_color = 'not_posted_color';
                         $posted_text  =   'Chưa đăng';
                    }
                    if($value['posted_customer'] == 1){
                         $postedCustomer_color = 'posted_color';
                         $postedCustomer_text  =   'khách hàng đã duyệt';
                    }else{
                         $postedCustomer_color = 'not_posted_color';
                         $postedCustomer_text  =   'khách hàng chưa duyệt';
                    }
                
                ?>
                             <span class="badge <?=  $posted_color ?>"><?= $posted_text ?></span>
                             <span class="badge <?=   $postedCustomer_color ?>"><?= $postedCustomer_text ?></span>
                                     <style>
                                           .posted_color{
                                               color: #ffffff;
                                                 background-color: #149701;
                                           }
                                             
                                            .not_posted_color{
                                                  color: #ffffff;
                                                 background-color: #ff5151;
                                            }
                                     </style>
                                  <?php }} ?>
                                
                                </td>

                                </tr>
                                <tr>
                                    <td>Ảnh</td>
                                    <td><a target="_blank" href="<?= base_url('image-list?ID=' . $keyword['ID']) ?>">Xem</a></td>
                                </tr>
                                <?php if ($role == 'admin') : ?>
                                    <tr>
                                        <td>Người viết</td>
                                        <td><?= $thisCTV; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Nhuận bút</td>
                                        <td><?= $price; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Liên hệ</td>
                                        <td><a target="_blank" href="https://zalo.me/<?= $ctv_info['phone']; ?>">Zalo</a></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                          <?php if ($role == 'admin') : ?>
                                    <?php
          $posted = result_select('keyword',[], []);
           foreach ($posted as $key => $value){
          if($value['ID'] == $keyword['ID'])
          if($value['finish'] == 3)
          if($value['posted'] == 0){
          ?>
                  <div class="card">
                 <div class="card-header border-0">
                    <form method="post" action="<?= base_url('keyword/posted'); ?>">
                     <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                   <input type="hidden" id="check" name="check" value="1">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-check"></i>&nbsp; Đăng</button>
                                </form> 
                        </div>         
                         </div>  
                 <?php }else{ ?>

                  <div class="card">
                 <div class="card-header border-0">
                    <form method="post" action="<?= base_url('keyword/check_posted'); ?>">
                     <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                   <input type="hidden" id="check" name="check" value="0">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-reply"></i></i>&nbsp; Hoàn tác </button>
                                </form> 
                        </div>         
                         </div>  
                       <?php } ?>
                          <?php } ?>
 <?php endif; ?>

  <?php if ($role == 'customer') : ?>
                                    <?php
          $posted = result_select('keyword',[], []);
           foreach ($posted as $key => $value){
          if($value['ID'] == $keyword['ID'])
          if($value['finish'] == 2)
          if($value['posted_customer'] == 0){
          ?>
                   <div class="card">
                 <div class="card-header border-0">
                    <form method="post" action="<?= base_url('keyword/posted_customer'); ?>">
                     <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                   <input type="hidden" id="check_customer" name="check_customer" value="1">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-check"></i>&nbsp; Duyệt</button>
                                </form> 
                        </div>         
                         </div>  
                 <?php }else{ ?>

                  <div class="card">
                 <div class="card-header border-0">
                    <form method="post" action="<?= base_url('keyword/check_posted_customer'); ?>">
                     <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                   <input type="hidden" id="check" name="check" value="0">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-reply"></i></i>&nbsp; Hoàn tác </button>
                                </form> 
                        </div>         
                         </div>  
                       <?php } ?>
                          <?php } ?>
 <?php endif; ?>
            <div id="sticky">
                <?php if ($role != 'ctv') : ?>
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Thao tác</h3>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-striped table-bordered table-valign-middle">
                                <tbody>
                                    <tr>
                                        <td>
                                            <?php if ($role == 'admin') : ?>
                                                <!-- Sửa thông tin -->
                                                <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#edit<?= $keyword['ID'] ?>">
                                                    <i class="fa-solid fa-note"></i>
                                                    </i>
                                                    Sửa thông tin
                                                </a>
                                                
                                                <!-- note -->
                                                <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#note<?= $keyword['ID'] ?>">
                                                    <i class="fa-solid fa-note"></i>
                                                    </i>
                                                    Note
                                                </a>
                                                
                                            <?php endif; ?>
                                            <?php if (!empty($button_approve_html)) {
                                                echo $button_approve_html;
                                            } ?>
                                            <?php if (!empty($button_point_html)) {
                                                echo $button_point_html;
                                            } ?>
                                            <?php if (!empty($button_customer_note_html)) {
                                                echo $button_customer_note_html;
                                            } ?>

                                            <?= $button_update_html; ?>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <?php if (!empty($button_delete_html)) {
                                                echo $button_delete_html;
                                            } ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
                 <?php if (!empty($keyword['note']) || !empty($keyword['customer_note'])) : ?>
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Góp ý</h3>
                        </div>
                        <div class="card-body ">
                            <?php if ($role == 'admin' || $role == 'ctv') : ?>
                                <?php if (!empty($keyword['note'])) : ?>
                                    <h5>Góp ý từ admin</h5>
                                    <div style="height: 250px; overflow: auto;"><?= $keyword['note']; ?></div>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if (!empty($keyword['customer_note'])) : ?>
                                <h5>Góp ý từ khách</h5>
                                <div style="height: 250px; overflow: auto;"><?= $keyword['customer_note']; ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
         </div>
          <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Keyword phụ</h3>
                        <?php if ($role == 'admin'){ ?>
                              <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#keywordSub" style="left:90%; position:absolute;">
                                                    <i class="fa-solid fa-note"></i>
                                                    </i>
                                                   Sửa
                                                </a>
                                                <?php }?>
                    </div>
                        <div class="card-body ">
                        <?= $keyword['sub_name'] ?>
                    </div>
                </div>
                  <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Lưu ý</h3>
                         <?php if ($role == 'admin'){ ?>
                         <a type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#keyword_note" style="left:90%; position:absolute;">
                                                    <i class="fa-solid fa-note"></i>
                                                    </i>
                                                   Sửa
                                                </a>
                                                <?php }?>
                    </div>                                   
                           <div class="card-body ">
                        <?= $keyword['keyword_note'] ?>
                    </div>
                    </div>
                    
               
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Outline</h3>
                    </div>
                    <div class="card-body ">
                        <?= $keyword['outline'] ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>   
    <div class="modal fade" id="edit<?= $keyword['ID'] ?>" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Sửa thông tin bài viết #<?= $keyword['ID'] ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="<?= base_url('keyword/edit-info') ?>">
                                                                    <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                                                    <div class="form-group">
                                                                        <label for="ctv">CTV</label>
                                                                        <select class="form-control select2bs4" name="ctv" style="width: 100%;" required>
                                                                            <?php
                                                                            $ctvs = result_select('users', ['role' => 'ctv'], ['id', 'username', 'fullname']);
                                                                            foreach ($ctvs as $key => $ctv) :
                                                                            ?>
                                                                                <option value="<?= $ctv['id'] ?>" <?= ($ctv['id'] == $keyword['ctv']) ? 'selected' : ''; ?>><?= $ctv['fullname'] ?></option>
                                                                            <?php endforeach; ?>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="deadline">Deadline</label>
                                                                        <input type="text" class="form-control" name="deadline" value="<?= $keyword['deadline'] ?>" required>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="outline_check">Có duyệt outline cho bài này không?</label>
                                                                        <select class="form-control" name="outline_check" required>
                                                                            <option value="0" <?= ($keyword['outline_check'] == 0) ? 'selected' : ''; ?>>Không</option>
                                                                            <option value="1" <?= ($keyword['outline_check'] == 1) ? 'selected' : ''; ?>>Có</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="finish_outline">Chuyển tình trạng outline</label>
                                                                        <select class="form-control" name="finish_outline" required>
                                                                            <option value="0" <?= ($keyword['finish_outline'] == 0) ? 'selected' : ''; ?>>Đang viết</option>
                                                                            <option value="2" <?= ($keyword['finish_outline'] == 2) ? 'selected' : ''; ?>>Chờ duyệt</option>
                                                                            <option value="1" <?= ($keyword['finish_outline'] == 1) ? 'selected' : ''; ?>>Hoàn thành</option>
                                                                        </select>
                                                                    </div>
                                                                    <button type="submit" class="btn btn-primary">Sửa</button>
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="note<?= $keyword['ID'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Góp ý bài viết #<?= $keyword['ID'] ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <form method="post" action="<?= base_url('keyword/note') ?>">
                                                                    <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                                                    <div class="form-group">
                                                                        <label for="note">Nội dung note</label>
                                                                        <textarea type="text" class="form-control tinymce-field" name="note"><?= $keyword['note'] ?></textarea>
                                                                    </div>
                                                                    <button type="submit" class="btn btn-primary">Góp ý</button>
                                                                </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal fade" id="keywordSub" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Sửa keyword phụ bài viết #<?= $keyword['ID'] ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                 <form method="post" action="<?= base_url('keyword/Update_sub_keyword') ?>">
                                                           <div class="form-group">                                     
                                                      <textarea class="form-control tinymce-field" name="sub_keyword" id="sub_keyword"><?= $keyword['sub_name'] ?></textarea>
                                                               <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                                            </div>
                                                               <button type="submit" class="btn btn-primary">Cập nhật</button>
                                                         </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                 <div class="modal fade" id="keyword_note" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="exampleModalLabel">Sửa Lưu ý bài viết #<?= $keyword['ID'] ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                             <form method="post" action="<?= base_url('keyword/Update_keyword_note') ?>">
                                                               <div class="form-group">                                     
                                                                 <textarea class="form-control tinymce-field" name="keyword_note" id="keyword_note"><?= $keyword['keyword_note'] ?></textarea>
                                                                   <input type="hidden" name="ID" value="<?= $keyword['ID'] ?>">
                                                                     </div>
                                                                      <button type="submit" class="btn btn-primary">Cập nhật</button>
                                                               </form>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
</section>




