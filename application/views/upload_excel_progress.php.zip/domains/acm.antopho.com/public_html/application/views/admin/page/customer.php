<?php
function edit_user_modal($user)
{
    return '
    <a type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editProject' . $user['id'] . '">
        <i class="fas fa-pencil-alt">
        </i>
        Chỉnh sửa
    </a>
    <div class="modal fade" id="editProject' . $user['id'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa CTV ' . $user['fullname'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="' . base_url('customer/edit') . '">
                    <input type="hidden" id="edit_id" name="edit_id" value="' . $user['id'] . '">
                    <div class="form-group">
                        <label for="edit_name">Tên khách</label>
                        <input type="text" class="form-control" id="edit_name" name="edit_name" value="' . $user['fullname'] . '" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_password">Password</label>
                        <input type="text" class="form-control" id="edit_password" name="edit_password" >
                    </div>                                  
                   
                    <button type="submit" class="btn btn-primary">Sửa</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}
//Thead
$thead_array = ['ID', 'Username', 'Tên khách hàng', 'Action'];
$thead_html = '';
foreach ($thead_array as $key => $thead_value) {
    $thead_html .= '<th class="text-center">' . $thead_value . '</th>';
}
//Tbody
$users = result_select('users', ['role' => 'customer'], []);
if ($role == 'ctv') {
    foreach ($users as $key => $value) {

        if ($value['id'] != $ctv_id) {
            unset($users[$key]);
        }
    }
}

$tbody_html = '';
foreach ($users as $key => $user) {
    $delete_button = '<a class="btn btn-danger btn-sm" href="' . base_url('customer/delete?id=' . $user['id']) . '" onclick="return confirm(\'Xác nhận xóa?\')">
                            <i class="fas fa-trash">
                            </i>
                            Xóa
                        </a>';

    $tbody_html .= '<tr>
                        <td class="text-center">' . $user['id'] . '</td>
                        <td class="text-center">' . $user['username'] . '</td>
                        <td class="text-center">' . $user['fullname'] . '</td>                       
                        <td class="project-actions">
                            ' . edit_user_modal($user) . '
                            ' . $delete_button . '
                        </td>
                    </tr>';
}

?>
<section class="content">
     <!-- Nút thêm khách hàng -->
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#addCustomer">
                    Thêm khách hàng
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addCustomer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Thêm khách hàng</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url('add-user'); ?>" method="post">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input class="form-control" id="username" name="username" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input class="form-control" id="password" name="password" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="fullname">Tên khách hàng</label>
                                        <input class="form-control" id="fullname" name="fullname" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">SDT</label>
                                        <input class="form-control" id="phone" name="phone">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Mail</label>
                                        <input type="email" class="form-control" id="email" name="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Thông tin thanh toán</label>
                                        <textarea class="form-control" id="address" name="address"></textarea>
                                    </div>
                                    <input type="hidden" class="form-control" id="role" name="role" value="customer">                  
                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Quản lý khách hàng</h3>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped projects">
                <thead>
                    <tr>
                        <?= $thead_html; ?>
                    </tr>
                </thead>
                <tbody>
                    <?= $tbody_html; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>