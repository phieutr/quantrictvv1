<?php

//Thead
$thead_array = ['ID','Bài viết', 'Người viết', 'STK', 'Bank', 'Chủ TK', 'Nhuận bút', 'Trạng thái', 'Ngày duyệt'];
$thead_html = '';
foreach ($thead_array as $key => $thead_value) {
    $thead_html .= '<th class="text-center">' . $thead_value . '</th>';
}
//Tbody
$fromDate = $this->input->get('fromDate');
$toDate = $this->input->get('toDate');

$keywords = result_select('keyword', ['finish' => 3], []);
// printR($keywords);
foreach ($keywords as $key => $value) {

    if (!empty($fromDate)) {
        if (strtotime($value['dateApproveMoney']) < strtotime($fromDate)) {
            unset($keywords[$key]);
        }
    }
    if (!empty($toDate)) {
        if (strtotime($value['dateApproveMoney']) > strtotime($toDate)) {
            unset($keywords[$key]);
        }
    }
}

$tbody_html = '';
foreach ($keywords as $key => $keyword) {
    $ctv_info = row_select('users', ['id' => $keyword['ctv']], []);
    $price = row_select('keyword_type_price', ['keyword_type_id' => $keyword['keyword_type'], 'word' => $keyword['word']], ['price'])['price'];
    $status = ($keyword['finish'] == 1) ? 'Đã duyệt' : 'Chưa duyệt';
     $url = base_url('preview/'.$keyword['ID']);
    $tbody_html .= '<tr>
                        <td class="text-center">' . $keyword['ID'] . '</td>
                        <td class="text-center"><a href="'.$url.'">' . $keyword['name'] . '</a></td>
                        <td class="text-center">' . @$ctv_info['fullname'] . ' (' . @$ctv_info['username'] . ')</td>
                        <td class="text-center">' . @$ctv_info['stk'] . '</td>
                        <td class="text-center">' . @$ctv_info['bank'] . '</td>                    
                        <td class="text-center">' . @$ctv_info['cardOwner'] . '</td> 
                        <td class="text-center">' . $price . '</td> 
                        <td class="text-center">' . $status  . '</td>
                        <td class="text-center">' . $keyword['dateApproveMoney']  . '</td>
                    </tr>';
}

?>
<section class="content">
    <div class="container-fluid">
        <div class="mb-2">
            <form method="get" action="<?= base_url('pay'); ?>" class="form-inline">
                <label class="sr-only" for="fromDate">Từ ngày</label>
                <input type="datetime-local" class="form-control mb-2 mr-sm-2" id="fromDate" name="fromDate">

                <label class="sr-only" for="toDate">Đến ngày</label>
                <input type="datetime-local" class="form-control mb-2 mr-sm-2" id="toDate" name="toDate">

                <button type="submit" class="btn btn-primary mb-2 btn-sm">Lọc</button>
            </form>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Quản lý nhuận</h3>
            </div>
            <div class="card-body">
                <table id="paydatatables" class="table table-striped">
                    <thead>
                        <tr>
                            <?= $thead_html; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?= $tbody_html; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>