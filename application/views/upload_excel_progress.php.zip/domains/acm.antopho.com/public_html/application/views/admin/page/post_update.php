<?php

$project = row_select('project', ['ID' => $keyword['project']], []);
$images = result_select('image', ['keyword_id' => $keyword['ID']], []);
//Trạng thái bài viết
// 0: Đang viết
// 1: Hoàn thành
// 2: Chờ duyệt
// 3: Đã duyệt, chờ thanh toán
// 4: Có góp ý

//Trạng thái outline
// 0: Đang viết
// 1: Đã duyệt outline
// 2: Chờ duyệt outline
?>
<section class="content">
    <div class="container-fluid">

        <form action="<?= base_url('keyword/edit'); ?>" method="post">
            <div class="row">
                <div class="col-9">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Nội dung</h3>
                        </div>
                        <div class="card-body">
                            <h5>Keyword: <span id="keyword_seo"><?= $keyword['name']; ?></span></h5>
                            <input type="hidden" id="id_update" name="ID" value="<?= $keyword['ID']; ?>">

                            <div class="form-group">
                                <label for="content">Nội dung (<span id="post_update_content"><?= str_word_count(convert_name(strip_tags($keyword['content']))); ?></span>)</label>
                                <?php if ($keyword['outline_check'] == 0) : ?>
                                    <textarea class="form-control tinymce-field-content" id="meta_content" name="content"><?= $keyword['content']; ?></textarea>
                                <?php else : ?>
                                    <?php if ($keyword['finish_outline'] == 1) : ?>
                                        <textarea class="form-control tinymce-field-content" id="meta_content" name="content"><?= $keyword['content']; ?></textarea>
                                    <?php else : ?>
                                        Xin vui lòng hoàn thành outline, sau khi duyệt outline, chúng tôi sẽ mở chức năng nội dung
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card card-primary card-outline card-outline-tabs">
                        <div class="card-header p-0 border-bottom-0">
                            <ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="custom-tabs-four-home-tab" data-toggle="pill" href="#custom-tabs-four-home" role="tab" aria-controls="custom-tabs-four-home" aria-selected="false">Post</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-four-profile-tab" data-toggle="pill" href="#custom-tabs-four-profile" role="tab" aria-controls="custom-tabs-four-profile" aria-selected="true">Media (<?= count($images); ?>)</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-four-messages-tab" data-toggle="pill" href="#custom-tabs-four-messages" role="tab" aria-controls="custom-tabs-four-messages" aria-selected="false">SEO (<span id="count_error">0</span>)</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="custom-tabs-four-settings-tab" data-toggle="pill" href="#custom-tabs-four-settings" role="tab" aria-controls="custom-tabs-four-settings" aria-selected="false">Activities</a>
                                </li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <div class="tab-content" id="custom-tabs-four-tabContent">
                                <!-- Tab 1 -->
                                <div class="tab-pane fade active show" id="custom-tabs-four-home" role="tabpanel" aria-labelledby="custom-tabs-four-home-tab">
                                    <div class="form-group">
                                        <label for="metaTitle">Meta Title (<span id="post_update_title"><?= mb_strlen($keyword['metaTitle'], 'utf-8') ?></span>)</label>
                                        <input type="text" class="form-control" name="metaTitle" id="meta_title" value="<?= $keyword['metaTitle']; ?>" required onkeyup="metaLength('title');">
                                    </div>
                                    <div class="form-group">
                                        <label for="metaDescription">Meta Description (<span id="post_update_description"><?= mb_strlen($keyword['metaDescription'], 'utf-8') ?></span>)</label>
                                        <input type="text" class="form-control" name="metaDescription" id="meta_description" value="<?= $keyword['metaDescription']; ?>" required onkeyup="metaLength('description');">
                                    </div>
                                    <?php if ($keyword['outline_check'] == 1) : ?>
                                        <div class="form-group">
                                            <label for="outline">Outline</label>
                                            <textarea class="form-control tinymce-field" name="outline"><?= $keyword['outline']; ?></textarea>
                                        </div>
                                        <?php if ($keyword['finish_outline'] != 1) : ?>
                                            <div class="form-group">
                                                <div class="form-check">
                                                    <?php
                                                    $display = '';
                                                    if ($keyword['finish_outline'] == 2) {
                                                        $display = 'checked="on"';
                                                    }
                                                    ?>
                                                    <input name="finish_outline" class="form-check-input" type="checkbox" id="finish_outline" <?php echo $display; ?>>
                                                    <label class="form-check-label" for="finish_outline">
                                                        Đã xong outline? Bấm để chờ duyệt
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if (!empty($keyword['sub_name'])) : ?>
                                        <hr>
                                        <h5>Keyword phụ</h5>
                                        <h5> <?= @$keyword['sub_name']; ?></h5>
                                    <?php endif; ?>

                                    <?php if (!empty($keyword['keyword_note'])) : ?>
                                        <hr>
                                        <h5>Lưu ý</h5>
                                        <h5> <?= @$keyword['keyword_note']; ?></h5>
                                    <?php endif; ?>

                                    <!-- <h5>Danh sách ảnh</h5>
                                    Xem tại <a target="_blank" href="<?= base_url('image-list?ID=' . $keyword['ID']) ?>">đây</a> -->


                                    <?php if (!empty($project['note'])) : ?>
                                        <hr>
                                        <h5>Lưu ý dự án</h5>
                                        <?= $project['note']; ?>
                                    <?php endif; ?>

                                    <?php if (!empty($keyword['note'])) : ?>
                                        <hr>
                                        <h5>Góp ý bài viết này</h5>
                                        <p style="color:red;"><?= $keyword['note']; ?></p>
                                    <?php endif; ?>

                                    <?php if (!empty($keyword['customer_note'])) : ?>
                                        <hr>
                                        <h5>Góp ý từ khách hàng</h5>
                                        <p style="color:red;"><?= $keyword['customer_note']; ?></p>
                                    <?php endif; ?>

                                </div>
                                <!-- Tab 2 -->
                                <div class="tab-pane fade" id="custom-tabs-four-profile" role="tabpanel" aria-labelledby="custom-tabs-four-profile-tab">
                                    <div class="mb-2">
                                        <!-- Nút thêm ảnh -->
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addPostImage">
                                            Đăng ảnh
                                        </button>
                                    </div>
                                    <hr>
                                    <h5>Danh sách ảnh</h5>
                                    <div class="row">
                                        <?php
                                        foreach ($images as $key => $image) :
                                            $url = base_url('assets/image/' . $image['image']);

                                        ?>
                                            <div class="col-sm-6">
                                                <a target="_blank" href="<?= $url; ?>"><img class="img-fluid" src="<?= $url; ?>"></a>
                                                <div style="background: #d6d6d6;padding: 5px;margin: 2px;"><small><?= $url; ?></small></div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <!-- Tab 3 -->
                                <div class="tab-pane fade" id="custom-tabs-four-messages" role="tabpanel" aria-labelledby="custom-tabs-four-messages-tab">
                                    <p id="meta_title_result"></p>
                                    <p id="meta_description_result"></p>
                                    <p id="meta_content_result"></p>
                                    <p id="meta_heading_result"></p>
                                </div>
                                <!-- Tab 4 -->
                                <div class="tab-pane fade" id="custom-tabs-four-settings" role="tabpanel" aria-labelledby="custom-tabs-four-settings-tab">

                                </div>
                            </div>
                        </div>
                        <!-- /.card -->
                    </div>

                    <?php if ($keyword['finish_outline'] == 1 || $keyword['outline_check'] == 0) : ?>
                        <div class="form-group">
                            <div class="form-check">
                                <?php
                                $display = '';
                                if ($keyword['finish'] == 1 || $keyword['finish'] == 2) {
                                    $display = 'checked="on"';
                                }
                                ?>
                                <input name="finish" class="form-check-input" type="checkbox" id="finish" <?php echo $display; ?>>
                                <label class="form-check-label" for="finish">
                                    Nộp bài cho Admin
                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="mb-2">
                        <button type="submit" class="btn btn-primary ">Lưu</button>
                        <a class="btn btn-info" target="_blank" href="<?= base_url('preview/' . $keyword['ID']); ?>">Xem trước</a>
                        <a href="<?= base_url('keyword'); ?>" type="button" class="btn btn-warning">Quay lại keyword</a>
                    </div>
                </div>
            </div>

        </form>
    </div>
</section>

<!-- Modal Them Anh -->
<div class="modal fade" id="addPostImage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Thêm ảnh</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= base_url('keyword/image'); ?>" enctype='multipart/form-data'>
                    <input type="hidden" name="ID" value="<?= $keyword['ID']; ?>">
                    <div class="custom-file">
                        <input type='file' name='files[]' multiple="">
                    </div>
                    <button type="submit" class="btn btn-primary">Thêm</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>