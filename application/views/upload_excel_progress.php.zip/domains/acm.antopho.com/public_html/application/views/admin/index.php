<?php
$main = $folder . '/' . $file . '.php';
$path = $this->uri->segment(1);
?>
<!DOCTYPE html>
<html lang="vi">

<head>
    <?php require_once 'templates/head.php'; ?>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <!-- Navbar -->
        <?php require_once 'templates/header.php'; ?>

        <!-- Sidebar -->
        <?php require_once 'templates/sidebar.php'; ?>

        <!-- Main -->
        <div class="content-wrapper">
            <?php require_once 'templates/title.php'; ?>
            <?php require_once $main; ?>
        </div>

        <?php require_once 'templates/footer.php'; ?>
    </div>

    <!-- jQuery -->
    <?php require_once 'templates/script.php'; ?>

</body>

</html>