<?php
$posts          = result_select('keyword', ['project' => $project['ID']], ['ID']);
$posts_num      = count($posts);

$posts_done         = result_select('keyword', ['project' => $project['ID'], 'finish' => 3], ['ID']);
$posts_done_num     = count($posts_done);

$posts_undone         = result_select('keyword', ['project' => $project['ID'], 'finish' => 0, 'ctv!=' => null], ['ID']);
$posts_undone_num     = count($posts_undone);

$outline_wait_approve         = result_select('keyword', ['project' => $project['ID'], 'finish_outline' => 2,  'outline_check' => 1, 'finish' => 0], ['ID']);
$outline_wait_approve_num     = count($outline_wait_approve);

$posts_wait_approve         = result_select('keyword', ['project' => $project['ID'], 'finish' => 2], ['ID']);
$posts_wait_approve_num     = count($posts_wait_approve);

$posts_have_note         = result_select('keyword', ['project' => $project['ID'], 'finish' => 4], ['ID']);
$posts_have_note_num     = count($posts_have_note);

$posts_not_choose           = result_select('keyword', ['project' => $project['ID'], 'finish' => 0, 'ctv' => null], ['ID']);
$posts_not_choose_num     = count($posts_not_choose);

//Tạo mảng xếp hạng CTV
$ctv_array = result_select('users', ['role' => 'ctv'], []);
$ctv_ranking_array = [];

foreach ($ctv_array as $key => $ctv_value) {
    $money_posts = result_select('keyword', ['ctv' => $ctv_value['id'], 'project' => $project['ID'], 'finish' => 1], ['keyword_type', 'word']);
    $point_posts_num = count($money_posts);
    if ($point_posts_num != 0) {
        $total_money = 0;
        foreach ($money_posts as $key => $money_post) {
            $total_money += row_select('keyword_type_price', ['keyword_type_id' => $money_post['keyword_type'], 'word' => $money_post['word']], ['price'])['price'];
        }
        $ctv_ranking_array[] = array(
            'name' => $ctv_value['fullname'],
            'money' => $total_money
        );
    }
}

//Đổ dữ liệu xếp hạng
$money_sort = array_column($ctv_ranking_array, 'money');
array_multisort($money_sort, SORT_DESC, $ctv_ranking_array);
$ctv_money_html = '';
foreach ($ctv_ranking_array as $key => $ctv_ranking_value) {
    if ($key < 5) {
        $ctv_money_html .= '  <tr>
                                <td>' . $ctv_ranking_value['name'] . '</td>
                                <td>' . number_format($ctv_ranking_value['money']) . '</td>
                            </tr>';
    }
}
?>
<div class="content">
    <div class="container-fluid">
         <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?= $posts_num; ?></h3>

                <p>Tổng số bài</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="<?= base_url('keyword?project_id=' . $project['ID']) ?>" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?= $posts_done_num; ?></h3>

                <p>Số bài hoàn thành</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="<?= base_url('keyword?status=3&project_id=' . $project['ID']) ?>" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?= $posts_wait_approve_num; ?></h3>

                <p>Số bài chờ duyệt</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="<?= base_url('keyword?status=2&project_id=' . $project['ID']) ?>" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?= $outline_wait_approve_num; ?></h3>

                <p>Số bài chờ duyệt Outline</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="<?= base_url('keyword?status=12&project_id=' . $project['ID']) ?>" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-<?= ($role != 'customer') ? 6 : 12 ?>">
                <!-- Tổng quan dự án -->
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Tình trạng các dự án</h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-striped table-valign-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>#</th>
                                    <th>#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Tổng số bài</td>
                                    <td><?= $posts_num; ?></td>
                                    <td><a href="<?= base_url('keyword?project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài hoàn thành</td>
                                    <td><?= $posts_done_num; ?></td>
                                    <td><a href="<?= base_url('keyword?status=3&project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài đang viết</td>
                                    <td><?= $posts_undone_num; ?></td>
                                    <td><a href="<?= base_url('keyword?status=5&project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài chờ duyệt outline</td>
                                    <td><?= $outline_wait_approve_num; ?></td>
                                    <td><a href="<?= base_url('keyword?status=12&project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
								<tr>
                                    <td>Số bài chờ duyệt content</td>
                                    <td><?= $posts_wait_approve_num; ?></td>
                                    <td><a href="<?= base_url('keyword?status=2&project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài có góp ý</td>
                                    <td><?= $posts_have_note_num; ?></td>
                                    <td><a href="<?= base_url('keyword?status=4&project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài chưa viết</td>
                                    <td><?= $posts_not_choose_num; ?></td>
                                    <td><a href="<?= base_url('keyword-choose?project_id=' . $project['ID']) ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Thông tin dự án -->
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Thông tin dự án</h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-striped table-valign-middle">
                            <thead>
                                <tr>
                                    <th>Dự án #</th>
                                    <th><?= $project['ID']; ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Khách hàng</td>
                                    <td><?= $project['customer']; ?></td>
                                </tr>
                                <tr>
                                    <td>Trạng thái</td>
                                    <td><?= ($project['status'] == 0) ? '<a class="btn btn-secondary btn-sm">Đang thực hiện</a>' : '<a class="btn btn-success btn-sm">Đã hoàn thành</a>' ?></td>
                                </tr>
                                <tr>
                                    <td>Ngày tạo</td>
                                    <td><?= $project['dateCreate']; ?></td>
                                </tr>
                                <tr>
                                    <td>Ngày bắt đầu</td>
                                    <td><?= $project['dateBegin']; ?></td>
                                </tr>
                                <tr>
                                    <td>Hạn chót</td>
                                    <td><?= $project['dateEnd']; ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php if ($role != 'customer') :  ?>
                <div class="col-lg-6">
                    <!-- Thành viên tham gia -->
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Thành viên tham gia</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>CTV</th>
                                        <th>Nhuận bút</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?= $ctv_money_html; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- Lưu ý dự án -->
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Lưu ý dự án</h3>
                        </div>
                        <div class="card-body table-responsive">
                            <?= $project['note']; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>