<?php
function edit_user_modal($user)
{
    return '
    <a type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editProject' . $user['id'] . '">
        <i class="fas fa-pencil-alt">
        </i>
        Chỉnh sửa
    </a>
    <div class="modal fade" id="editProject' . $user['id'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa CTV ' . $user['fullname'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
           <div class="modal-body">
                <form method="post" action="' . base_url('ctv/edit') . '">
                    <input type="hidden" id="edit_id" name="edit_id" value="' . $user['id'] . '">
                    <div class="form-group">
                        <label for="edit_name">Tên CTV</label>
                        <input type="text" class="form-control" id="edit_name" name="edit_name" value="' . $user['fullname'] . '" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_phone">SDT</label>
                        <input type="text" class="form-control" id="edit_phone" name="edit_phone" value="' . $user['phone'] . '" >
                    </div>
                    <div class="form-group">
                        <label for="edit_email">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="edit_email" value="' . $user['email'] . '" >
                    </div>                    
                    <div class="form-group">
                        <label for="edit_address">Số tài khoản</label>
                        <textarea type="text" class="form-control" id="edit_stk" name="edit_stk" required>' . $user['stk'] . '</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit_address">Ngân hàng</label>
                        <textarea type="text" class="form-control" id="edit_bank" name="edit_bank" required>' . $user['bank'] . '</textarea>
                    </div>
                    <div class="form-group">
                        <label for="edit_address">Tên người thụ hưởng</label>
                        <textarea type="text" class="form-control" id="edit_cardOwner" name="edit_cardOwner" required>' . $user['cardOwner'] . '</textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Sửa</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}
//Thead
$thead_array = ['ID', 'Username', 'Tên CTV', 'Thông tin thanh toán', 'Đã hoàn thành', 'Chờ thanh toán', 'Action'];
$thead_html = '';
foreach ($thead_array as $key => $thead_value) {
    $thead_html .= '<th class="text-center">' . $thead_value . '</th>';
}
//Tbody
$users = result_select('users', ['role' => 'ctv'], []);
if ($role == 'ctv') {
    foreach ($users as $key => $value) {

        if ($value['id'] != $ctv_id) {
            unset($users[$key]);
        }
    }
}

$tbody_html = '';
foreach ($users as $key => $user) {
    $delete_button = '<a class="btn btn-danger btn-sm" href="' . base_url('ctv/delete?id=' . $user['id']) . '" onclick="return confirm(\'Xác nhận xóa?\')">
                            <i class="fas fa-trash">
                            </i>
                            Xóa
                        </a>';
    if ($role == 'ctv') {
        $delete_button = '';
    }
    $posts = result_select('keyword', ['ctv' => $user['id']], []);
    $posts_done = 0;
    $posts_wait_pay = 0;
    foreach ($posts as $key => $post) {
        if ($post['finish'] == 1) {
            $posts_done += 1;
        }
        if ($post['finish'] == 3) {
            $posts_wait_pay += 1;
        }
    }

    $tbody_html .= '<tr>
                        <td class="text-center">' . $user['id'] . '</td>
                        <td class="text-center">' . $user['username'] . '</td>
                        <td class="text-center">' . $user['fullname'] . '</td>
                        <td class="text-center">' . $user['stk'] . '<br>' . $user['bank'] . '<br>' . $user['cardOwner'] . '</td>                    
                        <td class="text-center">' . $posts_done . '/' . count($posts) . '</td>
                        <td class="text-center">' . $posts_wait_pay  . '</td>
                        <td class="project-actions">
                            ' . edit_user_modal($user) . '
                            ' . $delete_button . '
                        </td>
                    </tr>';
}

?>
<section class="content">
    <?php if ($role == 'admin') : ?>
        <div class="mb-2">
            <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#add_shop">
                Thêm CTV
            </button>
            <div class="modal fade" id="add_shop" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Thêm CTV</h5>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('add-user'); ?>" method="post">
                                <div class="form-group">
                                    <label for="username">Username</label>
                                    <input class="form-control" id="username" name="username" required>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input class="form-control" id="password" name="password" required>
                                </div>
                                <div class="form-group">
                                    <label for="fullname">Tên CTV</label>
                                    <input class="form-control" id="fullname" name="fullname" required>
                                </div>
                                <div class="form-group">
                                    <label for="phone">SDT</label>
                                    <input class="form-control" id="phone" name="phone">
                                </div>
                                <div class="form-group">
                                    <label for="email">Mail</label>
                                    <input type="email" class="form-control" id="email" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="stk">Số tài khoản</label>
                                    <input class="form-control" id="stk" name="stk" required>
                                </div>
                                <div class="form-group">
                                    <label for="bank">Ngân hàng</label>
                                    <input class="form-control" id="bank" name="bank" required>
                                </div>
                                <div class="form-group">
                                    <label for="cardOwner">Tên người thụ hưởng</label>
                                    <input class="form-control" id="cardOwner" name="cardOwner" required>
                                </div>
                                <input type="hidden" class="form-control" id="role" name="role" value="ctv">

                                <button type="submit" class="btn btn-primary">Thêm</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Quản lý CTV</h3>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped projects">
                <thead>
                    <tr>
                        <?= $thead_html; ?>
                    </tr>
                </thead>
                <tbody>
                    <?= $tbody_html; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>