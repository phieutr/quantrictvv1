<?php
$where_done_array = ['status' => 1];
$where_undone_array = ['status' => 0];
if (!empty($customer_id)) {
    $where_done_array['customer'] = $customer_id;
    $where_undone_array['customer'] = $customer_id;
}
$project_num        = count($projects_array);
//Đã hoàn thành
$project_done_array = result_select('project', $where_done_array, []);
$project_done_num   = count($project_done_array);
//Chưa hoàn thành
$project_undone_array = result_select('project', $where_undone_array, []);
$project_undone_num   = count($project_undone_array);
//Tổng số bài
$allposts          = result_select('keyword', ['name!=' => null], []);
$allposts_num      = count($allposts);
//Tổng số bài đã nghiệm thu
$allpostsdone          = result_select('keyword', ['finish' => 3], []);
$allpostsdone_num      = count($allpostsdone);
//Tổng số bài chờ duyệt
$allposts_wait_approve          = result_select('keyword', ['finish' => 2], []);
$allposts_wait_approve_num      = count($allposts_wait_approve);
//Tạo mảng xếp hạng CTV
$ctv_array = result_select('users', ['role' => 'ctv'], []);
$ctv_ranking_array = [];

foreach ($ctv_array as $key => $ctv_value) {
    $point_posts = result_select('keyword', ['ctv' => $ctv_value['id'], 'finish' => 1], ['point', 'keyword_type', 'word']);
    $point_posts_num = count($point_posts);
    if ($point_posts_num == 0) {
        $ctv_ranking_array[] = array(
            'name' => $ctv_value['fullname'],
            'point' => 0,
            'money' => 0
        );
    } else {
        $total_point = 0;
        $total_money = 0;
        $post_pointed = 0;
        foreach ($point_posts as $key => $point_post) {
            if ($point_post['point'] != 0) {
                $total_point += $point_post['point'];
                $post_pointed += 1;
            }
            $total_money += row_select('keyword_type_price', ['keyword_type_id' => $point_post['keyword_type'], 'word' => $point_post['word']], ['price'])['price'];
        }
        $ctv_ranking_array[] = array(
            'name' => $ctv_value['fullname'],
            'point' => ($post_pointed == 0) ? 0 : $total_point / $post_pointed,
            'money' => $total_money
        );
    }
}

//Đổ dữ liệu xếp hạng
$point_sort = array_column($ctv_ranking_array, 'point');
array_multisort($point_sort, SORT_DESC, $ctv_ranking_array);
$ctv_point_html = '';
foreach ($ctv_ranking_array as $key => $ctv_ranking_value) {
    if ($key < 5) {
        $ctv_point_html .= '  <tr>
        <td>' . $ctv_ranking_value['name'] . '</td>
        <td>' . $ctv_ranking_value['point'] . '</td>
    </tr>';
    }
}
$money_sort = array_column($ctv_ranking_array, 'money');
array_multisort($money_sort, SORT_DESC, $ctv_ranking_array);
$ctv_money_html = '';
foreach ($ctv_ranking_array as $key => $ctv_ranking_value) {
    if ($key < 5) {
        $ctv_money_html .= '  <tr>
                                <td>' . $ctv_ranking_value['name'] . '</td>
                                <td>' . number_format($ctv_ranking_value['money']) . '</td>
                            </tr>';
    }
}

//Bài chậm deadline
$deadline_posts = result_select('keyword', ['finish!=' => 1], []);
$deadline_post_num = 0;
foreach ($deadline_posts as $key => $deadline_post) {
    if (strtotime($deadline_post['deadline']) < strtotime('now')) {
        $deadline_post_num += 1;
    }
}

$untake_posts = result_select('keyword', ['ctv' => null], []);

// biểu đồ dữ liệu chậm deadline ctv
$users = result_select('users', ['role' => 'ctv'], []);
foreach ($users as $key => $user){

$posts_ctv         = result_select('keyword', ['finish!=' => 3,'ctv' => $user['id']], []);
$posts_check_ctv         = result_select('keyword', ['finish' => 1,'ctv' => $user['id']], []);
 $posts_num_finish = count($posts_check_ctv);
 $posts_num_ctv     = count($posts_ctv);
 $posts_check_num_ctv  =  $posts_num_ctv - $posts_num_finish ;
 


//Bài chậm deadline
$deadline_posts = result_select('keyword', ['finish!=' => 3,'ctv' => $user['id']], []);
$deadline_post_num_ctv = 0;
foreach ($deadline_posts as $key => $deadline_post) {
    if (strtotime($deadline_post['deadline']) < strtotime('now')) {
        $deadline_post_num_ctv += 1;
        $posts_check_ctv         = result_select('keyword', ['finish' => 1,'ctv' => $user['id']], []);
        $posts_num_finish = count($posts_check_ctv);
    
         $deadline_check_num_ctv_antopho  =  $deadline_post_num_ctv - $posts_num_finish ;
         
    }
   
}    if( $posts_check_num_ctv > 0 ){
    $algorithm = $deadline_check_num_ctv_antopho/$posts_check_num_ctv;
    $algorithm_ctv = $algorithm * 100;
}else{
     $algorithm_ctv = 0;
}



    $tbody_html .= '<tr>
                      
                       <div class="progress-group">
                        <td class="text-center">' . $user['fullname'] .'</td>
                     <td> <span class="float-right"><b>' . $deadline_check_num_ctv_antopho.'</b>/' . $posts_check_num_ctv  . '</span></td>
                     <td> <div class="progress progress-sm"></td>
                        <td><div class="progress-bar bg-danger" style="width: ' . $algorithm_ctv . '%"></div>
                      </div></td>
                    </div>
                  
                    </tr>';


}
?>
<div class="content">
    <div class="container-fluid">
         <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?= $project_num; ?></h3>

                <p>Tổng số dự án</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?= $allposts_num; ?></h3>

                <p>Tổng số bài</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="#" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?= $allpostsdone_num; ?></h3>

                <p>Tổng số bài đã nghiệm thu</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?= $allposts_wait_approve_num; ?></h3>

                <p>Số bài chờ duyệt</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="<?= base_url('keyword?status=2') ?>" class="small-box-footer">Xem tất cả <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            
            <div class="col-lg-<?= ($role != 'customer') ? 6 : 12 ?>">
                <!-- Tổng quan dự án -->
                <div class="card">
                    <div class="card-header border-0">
                        <h3 class="card-title">Tình trạng các dự án</h3>
                    </div>
                    <div class="card-body table-responsive p-0">
                        <table class="table table-striped table-valign-middle">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>#</th>
                                    <th>#</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Tổng dự án</td>
                                    <td><?= $project_num; ?></td>
                                    <td><a href="<?= base_url('project') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Tổng số bài</td>
                                    <td><?= $allposts_num; ?></td>
                                    <td><a href="<?= base_url('project') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                 <tr>
                                    <td>Tổng số bài đã nghiệm thu</td>
                                    <td><?= $allpostsdone_num; ?></td>
                                    <td><a href="<?= base_url('project') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số dự án hoàn thành</td>
                                    <td><?= $project_done_num; ?></td>
                                    <td><a href="<?= base_url('project') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số dự án đang thực hiện</td>
                                    <td><?= $project_undone_num; ?></td>
                                    <td><a href="<?= base_url('project') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài chậm deadline</td>
                                    <td><?= $deadline_post_num; ?></td>
                                    <td><a href="<?= base_url('keyword') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                                <tr>
                                    <td>Số bài CTV chưa viết</td>
                                    <td><?= count($untake_posts) ?></td>
                                    <td><a href="<?= base_url('keyword-choose') ?>" type="button" class="btn btn-info btn-sm">Xem</a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Hoạt động dự án -->
                <?php if ($role != 'customer') :  ?>
                    <!-- <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Tình trạng các dự án</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>Hoạt động</th>
                                        <th>Thời gian</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Admin vừa giao bài viết cho CTV Nguyễn Văn A</td>
                                        <td><?= date('Y/m/d H:i:s'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Admin vừa giao bài viết cho CTV Nguyễn Văn A</td>
                                        <td><?= date('Y/m/d H:i:s'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Admin vừa giao bài viết cho CTV Nguyễn Văn A</td>
                                        <td><?= date('Y/m/d H:i:s'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Admin vừa giao bài viết cho CTV Nguyễn Văn A</td>
                                        <td><?= date('Y/m/d H:i:s'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Admin vừa giao bài viết cho CTV Nguyễn Văn A</td>
                                        <td><?= date('Y/m/d H:i:s'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div> -->
                <?php endif; ?>

            </div>
            <?php if ($role != 'customer') :  ?>

                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Xếp hạng CTV</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>CTV</th>
                                        <th>Điểm</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?= $ctv_point_html; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->

                    <div class="card">
                        <div class="card-header border-0">
                            <h3 class="card-title">Nhuận bút</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-striped table-valign-middle">
                                <thead>
                                    <tr>
                                        <th>CTV</th>
                                        <th>Nhuận bút</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?= $ctv_money_html; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>

    </div>

</div>
<!-- biểu đồ chậm dealine của ctv -->
 <?php if ($role == 'admin') : ?>
<div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">Số bài chậm/tất cả bài nhận</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="card-refresh" data-source="widgets.html" data-source-selector="#card-refresh-content" data-load-on-init="false">
                    <i class="fas fa-sync-alt"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="maximize">
                    <i class="fas fa-expand"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                   <tbody>
                    <?= $tbody_html; ?>
                </tbody>
                    </div>
<?php endif; ?>
    
