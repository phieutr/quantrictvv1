<?php
function edit_keyword_type_modal($keyword_type)
{
    $rate_array = result_select('keyword_type_price', ['keyword_type_id' => $keyword_type['ID']], []);
    $rate_html = '';
    $n = 10;
    for ($i = 1; $i <= $n; $i++) {
        $offset = $i - 1;
        $rate_html .= ' <tr class="text-center">
                            <td><input class="form-control" name="word' . $i . '" id="word' . $i . '" value="' . @$rate_array[$offset]['word'] . '"></td>
                            <td><input class="form-control" name="price' . $i . '" id="price' . $i . '" value="' . @$rate_array[$offset]['price'] . '"></td>
                            <input type="hidden" id="ID' . $i . '" name="ID' . $i . '" value="' . @$rate_array[$offset]['ID'] . '">
                        </tr>';
    }
    return '
    <a type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editKeywordType' . $keyword_type['ID'] . '">
        <i class="fas fa-pencil-alt">
        </i>
        Chỉnh sửa
    </a>
    <div class="modal fade" id="editKeywordType' . $keyword_type['ID'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa dạng từ khóa ' . $keyword_type['name'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="' . base_url('keyword-type/edit') . '">
                    <input type="hidden" id="edit_id" name="edit_id" value="' . $keyword_type['ID'] . '">
                    <div class="form-group">
                        <label for="edit_name">Tên dạng từ khóa</label>
                        <input type="text" class="form-control" id="edit_name" name="edit_name" value="' . $keyword_type['name'] . '" required>
                    </div>
                    <h5>Nhuận</h5>
                    <table class="table">
                        <thead>
                            <tr class="text-center">
                                <th>Số từ</th>
                                <th>Giá tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            ' . $rate_html . '
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Sửa</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}
$keyword_types = result_select('keyword_type', [], []);
//Bảng
$headers = ['ID', 'Dạng từ khóa', ''];
$header_html = '';
foreach ($headers as $key => $header) {
    $header_html .= '<th class="text-center">' . $header . '</th>';
}
$header_html = '<thead><tr>' . $header_html . '</tr></thead>';

$body_html = '';
foreach ($keyword_types as $key => $keyword_type) {
    $body_html .= ' <tr>
                        <td class="text-center">#' . $keyword_type['ID'] . '</td>
                        <td class="text-center">' . $keyword_type['name'] . '</td>                        
                
                        <td class="project-actions">                              
                                ' . edit_keyword_type_modal($keyword_type) . '
                                <a class="btn btn-danger btn-sm" href="' . base_url('keyword-type/delete?ID=' . $keyword_type['ID']) . '" onclick="return confirm(\'Xác nhận xóa?\')">
                                    <i class="fas fa-trash">
                                    </i>
                                    Xóa
                                </a>
                        </td>
                    </tr>';
}
$body_html = '<tbody><tr>' . $body_html . '</tr></tbody>';
?>
<section class="content">
    <div class="container-fluid">
        <div class="mb-2">
            <!-- Nút thêm dạng từ khóa -->
            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addKeywordType">
                Thêm dạng từ khóa
            </button>

            <!-- Modal -->
            <div class="modal fade" id="addKeywordType" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Thêm dạng từ khóa</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="post" action="<?= base_url('keyword-type/add'); ?>">
                                <div class="form-group">
                                    <label for="name">Tên dạng từ khóa</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>

                                <h5>Nhuận bút</h5>
                                <table class="table">
                                    <thead>
                                        <tr class="text-center">
                                            <th>Số từ</th>
                                            <th>Giá tiền</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $n = 10;
                                        for ($i = 1; $i <= $n; $i++) :
                                        ?>
                                            <tr class="text-center">
                                                <td><input class="form-control" name="word<?= $i; ?>" id="word<?= $i; ?>"></td>
                                                <td><input class="form-control" name="price<?= $i; ?>" id="price<?= $i; ?>"></td>
                                            </tr>
                                        <?php
                                        endfor;
                                        ?>
                                    </tbody>
                                </table>

                                <button type="submit" class="btn btn-primary">Thêm</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Quản lý dạng từ khóa</h3>
            </div>
            <div class="card-body p-0">
                <table class="table projects">
                    <?= $header_html; ?>
                    <?= $body_html; ?>
                </table>
            </div>
        </div>
    </div>
</section>