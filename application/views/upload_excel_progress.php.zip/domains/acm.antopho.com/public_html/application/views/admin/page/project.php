<?php
$customers = result_select('users', ['role' => 'customer'], []);
$customer_option_html = '<option selected>-Chọn khách hàng-</option>';
foreach ($customers as $key => $customer) {
    $customer_option_html .= '<option value="' . $customer['id'] . '">' . $customer['fullname'] . '</option>';
}
function option_customer($id)
{
    $customers = result_select('users', ['role' => 'customer'], []);

    $html = '';
    foreach ($customers as $key => $customer) {
        if ($customer['id'] == $id) {
            $html .= '<option value="' . $customer['id'] . '" selected>' . $customer['fullname'] . '</option>';
        } else {
            $html .= '<option value="' . $customer['id'] . '">' . $customer['fullname'] . '</option>';
        }
    }
    return $html;
}

function edit_project_modal($project)
{
    $display = '';
    if ($project['status'] == 1) {
        $display = 'checked="on"';
    }

    return '
    <a type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editProject' . $project['ID'] . '">
        <i class="fas fa-pencil-alt">
        </i>
        Chỉnh sửa
    </a>
    <div class="modal fade" id="editProject' . $project['ID'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Chỉnh sửa dự án #' . $project['ID'] . '</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="' . base_url('project/edit') . '">
                    <input type="hidden" id="edit_id" name="edit_id" value="' . $project['ID'] . '">
                    <div class="form-group">
                        <label for="edit_name">Tên dự án</label>
                        <input type="text" class="form-control" id="edit_name" name="edit_name" value="' . $project['name'] . '" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_customer">Khách hàng</label>
                        <select class="form-control" id="edit_customer" name="edit_customer" required>
                        ' . option_customer($project['customer']) . '
                        </select>                        
                    </div>
                    <div class="form-group">
                        <label for="edit_dateBegin">Ngày bắt đầu</label>
                        <input type="datetime-local" class="form-control" id="edit_dateBegin" name="edit_dateBegin" value="' . $project['dateBegin'] . '" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_dateEnd">Ngày kết thúc</label>
                        <input type="datetime-local" class="form-control" id="edit_dateEnd" name="edit_dateEnd" value="' . $project['dateEnd'] . '" required>
                    </div>
                    <div class="form-group">
                        <label for="edit_note">Lưu ý dự án</label>
                        <textarea class="form-control tinymce-field" name="edit_note">' . $project['note'] . '</textarea>                   
                    </div>
                    <div class="form-group float-right">
                        <input name="status" class="form-check-input" type="checkbox" id="status" ' . $display . '>
                        <label class="form-check-label" for="status">
                            Dự án đã hoàn thành?
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary">Sửa</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>';
}
function delete_project_modal($project)
{
    return '
    <a class="btn btn-danger btn-sm" href="' . base_url('project/delete?ID=' . $project['ID']) . '" onclick="return confirm(\'Xác nhận xóa? Nếu ok sẽ xóa toàn bộ từ khóa của bài viết này\')">
        <i class="fas fa-trash">
        </i>
        Xóa
    </a>';
}
$where_array = [];
if (!empty($customer_id)) {
    $where_array['customer'] = $customer_id;
}
$projects = result_select('project', $where_array, []);


//Bảng
$headers = ['ID', 'Tên dự án', 'Ngày bắt đầu', 'Ngày kết thúc', 'CTV', 'Trạng thái'];
$header_html = '';
foreach ($headers as $key => $header) {
    $header_html .= '<th class="text-center">' . $header . '</th>';
}
$header_html = '<thead><tr>' . $header_html . '</tr></thead>';
  
$body_html = '';
foreach ($projects as $key => $project) {
    $edit_modal_html = (!empty($customer_id)) ? '' : edit_project_modal($project);
    $delete_modal_html = (!empty($customer_id)) ? '' : delete_project_modal($project);
    $ctv = '';
    $ctv_ids = result_select('project_users', ['idProject' => $project['ID']], []);
    if (!empty($ctv_ids)) {
        foreach ($ctv_ids as $key => $ctv_id) {
            $ctv_info = row_select('users', ['id' => $ctv_id['idUser']], ['fullname', 'id']);
            $ctv .= '
            <tr id="project' . $project['ID'] . 'removeCTV' . $ctv_info['id'] . '">
                <td>' . $ctv_info['fullname'] . '</td>
                <td><a class="btn btn-danger btn-sm" onclick="projectRemoveCTV(' . $project['ID'] . ',' . $ctv_info['id'] . ');">Xóa khỏi dự án</a></td>
            </tr>';
        }
    }

  $link = base_url('dashboard?project_id='.$project['ID'].'');
    $status = ($project['status'] == 0) ? '<a class="btn btn-secondary btn-sm">Đang thực hiện</a>' : '<a class="btn btn-success btn-sm">Đã hoàn thành</a>';
    $body_html .= ' <tr>
                        <td class="text-center">#' . $project['ID'] . '</td>
                      <td class="text-center">  <a href="'.$link.'">' . $project['name'] . '</a></td>
                        <td class="text-center">' . $project['dateBegin'] . '</td>
                        <td class="text-center">' . $project['dateEnd'] . '</td>
                        <td class="text-center">
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#ctvproject' . $project['ID'] . '">
                        Xem
                        </button>                     
                      
                        <div class="modal fade" id="ctvproject' . $project['ID'] . '" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Danh sách CTV</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                <table class="table table-sm projects">
                                    <tbody>
                                    ' . $ctv . '
                                    </tbody>
                                </table>                                
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Đóng</button>                         
                                </div>
                            </div>
                            </div>
                        </div>
                        </td>
                        <td class="text-center">' . $status . '</td>
                       
                        <td class="project-actions">                    
                            ' . $edit_modal_html . $delete_modal_html . '
                        </td>
                    </tr>';
}
$body_html = '<tbody><tr>' . $body_html . '</tr></tbody>';
?>
<section class="content">
    <div class="container-fluid">
        <?php if ($role != 'customer') :  ?>
            <div class="mb-2">
                <!-- Nút thêm dự án -->
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addProject">
                    Thêm dự án
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addProject" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Thêm dự án</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="<?= base_url('project/add'); ?>">
                                    <div class="form-group">
                                        <label for="name">Tên dự án</label>
                                        <input type="text" class="form-control" id="name" name="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="customer">Khách hàng</label>
                                        <select class="form-control" id="customer" name="customer" required>
                                            <?= $customer_option_html; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="dateBegin">Ngày bắt đầu</label>
                                        <input type="datetime-local" class="form-control" id="dateBegin" name="dateBegin" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="dateEnd">Ngày kết thúc</label>
                                        <input type="datetime-local" class="form-control" id="dateEnd" name="dateEnd" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="note">Lưu ý dự án</label>
                                        <textarea class="form-control tinymce-field" name="note"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Nút thêm khách hàng -->
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#addCustomer">
                    Thêm khách hàng
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addCustomer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Thêm khách hàng</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url('add-user'); ?>" method="post">
                                    <div class="form-group">
                                        <label for="username">Username</label>
                                        <input class="form-control" id="username" name="username" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input class="form-control" id="password" name="password" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="fullname">Tên khách hàng</label>
                                        <input class="form-control" id="fullname" name="fullname" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">SDT</label>
                                        <input class="form-control" id="phone" name="phone">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Mail</label>
                                        <input type="email" class="form-control" id="email" name="email">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Thông tin thanh toán</label>
                                        <textarea class="form-control" id="address" name="address"></textarea>
                                    </div>

                                    <input type="hidden" class="form-control" id="role" name="role" value="customer">

                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Nút thêm ctv -->
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#addProjectCTV">
                    Thêm CTV vào dự án
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addProjectCTV" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Thêm CTV vào dự án</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?= base_url('project/add_ctv'); ?>" method="post">
                                    <div class="form-group">
                                        <label for="project">Dự án</label>
                                        <select class="form-control" id="project" name="project" required>
                                            <option selected>--Chọn dự án--</option>
                                            <?php
                                            $all_projects = result_select('project', [], ['ID', 'name']);
                                            foreach ($all_projects as $key => $v_project) : ?>
                                                <option value="<?= $v_project['ID'] ?>"><?= $v_project['name'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="ctv">CTV</label>
                                        <select class="form-control" name="ctv[]" multiple required>
                                            <?php
                                            $all_ctv = result_select('users', ['role' => 'ctv'], ['id', 'fullname']);
                                            foreach ($all_ctv as $key => $v_ctv) : ?>
                                                <option value="<?= $v_ctv['id'] ?>"><?= $v_ctv['fullname'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Bảng quản lý dự án -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Quản lý dự án</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped projects">
                    <?= $header_html; ?>
                    <?= $body_html; ?>
                </table>
            </div>
        </div>
    </div>
</section>