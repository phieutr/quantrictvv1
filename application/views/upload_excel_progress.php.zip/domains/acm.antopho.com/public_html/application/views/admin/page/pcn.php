<?php
//Thêm keyword - project
$option_projects_html = '<option selected>--Chọn dự án--</option>';
foreach ($projects_array as $key => $projects_value) {
    $option_projects_html .= '<option value="' . $projects_value['ID'] . '">' . $projects_value['name'] . '</option>';
}
//Thêm keyword - keyword_type
$keyword_types_array = result_select('keyword_type', [], []);
$keyword_types_html = '<option selected>--Chọn dạng từ khóa--</option>';
foreach ($keyword_types_array as $key => $keyword_types_value) {
    $keyword_types_html .= '<option value="' . $keyword_types_value['ID'] . '">' . $keyword_types_value['name'] . '</option>';
}
//Keyword trống
$available_keyword_header_array = ['Keyword','Keyword phụ','Chọn ctv','Deadline', 'Dạng từ khóa','Dự án', 'Số từ',];
$available_keyword_header_html = '';
foreach ($available_keyword_header_array as $key => $available_keyword_header_value) {
    $available_keyword_header_html .= '<th>' . $available_keyword_header_value . '</th>';
}

$where_array = ['ctv' => null];
if (!empty($project)) {
    $where_array['project'] = $project['ID'];
}
$available_keyword_array = result_select('keyword', $where_array, []);

if ($role == 'ctv') {
    foreach ($available_keyword_array as $key => $value) {
        $check_user = row_select('project_users', ['idProject' => $value['project'], 'idUser' => $session_user['id']], []);
        if (empty($check_user)) {
            unset($available_keyword_array[$key]);
        }
    }
}



$give_ctv_option_html = '<option value="0" selected>--Chọn CTV--</option>';
$ctv = result_select('users', ['role' => 'ctv'], []);
foreach ($ctv as $key => $value) {
    $give_ctv_option_html .= '<option value="' . $value['id'] . '">' . $value['fullname'] . '</option>';
            $test = $value['id'];

}






$available_keyword_html = '';
foreach ($available_keyword_array as $key => $available_keyword_value) {
    $choose_url = base_url('keyword/pcn'); 
    if (!empty($customer_id)) {
        $choose_url = '';
    }

   if($available_keyword_value['sub_name'] == ''){
       $yes = "không có keyword phụ";
   }else{
              $yes = " có keyword phụ";
   }

    $thisType = row_select('keyword_type', ['ID' => $available_keyword_value['keyword_type']], ['name'])['name'];
    $thisProject = row_select('project', ['ID' => $available_keyword_value['project']], ['name'])['name'];

    $available_keyword_html .= '   <form method="post" action="' . $choose_url .'">
                                    <div class="form-group">
                                    <td>
                                     <div class="form-groupp">
                                    
                                        <select class="form-control" name="ID" required>
                                           <option  value="' . $available_keyword_value['ID'] . '">' . $available_keyword_value['name'] . '</option >
                                        
                                        </select>
                                        
                                        
                                    </div>
                                  
                                    </td>
                                     <td>
                                     <div class="form-groupp">    
                                      '.$yes.'
                                        
                                    </div>
                                  
                                    </td>
                                     <td>
                                     
                                      <select class="form-control" name="ctv" required>
                                        '. $give_ctv_option_html.'
                                     </select>
                                      </td>
                                            <td>' . $available_keyword_value['deadline'] . '</td>
                                    <td>' . $thisType . '</td>
                                    <td>' . $thisProject . '</td>
                                    <td>' . $available_keyword_value['word'] . '</td>
                                    
                                   
                                    <td> <button type="submit" class="btn btn-primary" required>Phân công</button></td>
                                     
                                </tr>
                                </div>
                                 </form>';

    
}


?>



<section class="content">
    <div class="container-fluid">
        <?php if ($role == 'admin') : ?>
            <div class="mb-2">
                <!-- Nút thêm keyword -->
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addKeyword">
                    Thêm từ khóa
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addKeyword" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Thêm từ khóa</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form method="post" action="<?= base_url('keyword/addd_keyword'); ?>">
                                    <div class="form-group">
                                        <label for="name">Từ khóa</label>
                                        <input type="text" class="form-control" id="name" name="name" required>
                                    </div>
                                   
                                      <div class="form-group">
                                        <label for="note">Từ khóa phụ</label>
                                        <textarea class="form-control tinymce-field" name="sub_name" id="sub_name"></textarea>
                                    </div>
                                        <div class="form-group">
                                        <label for="note">Lưu ý</label>
                                        <textarea class="form-control tinymce-field" name="keyword_note" id="keyword_note"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="project">Dự án</label>
                                        <select class="form-control" id="project" name="project" required>
                                            <?= $option_projects_html; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="keyword_type">Dạng từ khóa</label>
                                        <select class="form-control" id="keyword_type" name="keyword_type" required>
                                            <?= $keyword_types_html; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="word">Số từ</label>
                                        <input type="number" class="form-control" id="word" name="word" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="deadline">Deadline</label>
                                        <input type="datetime-local" class="form-control" id="deadline" name="deadline" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="outline_check">Duyệt outline?</label>
                                        <select class="form-control" id="outline_check" name="outline_check" required>
                                            <option value="0">Không</option>
                                            <option value="1">Có</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                               <!-- Nút excel -->
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#addExcel">
                    Đăng Excel
                </button>

                <!-- Modal -->
                <div class="modal fade" id="addExcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">

                                <h5 class="modal-title" id="exampleModalLabel">Đăng Excel</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <a href="<?= base_url('keyword/upload-excel'); ?>">Tải về bản mẫu</a>
                                <form method="post" action="<?= base_url('keyword/excel'); ?>" enctype='multipart/form-data'>
                                    <div class="custom-file">
                                        <input type='file' name='file' multiple="">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Thêm</button>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        <?php endif; ?>
        <div class="card">
            <div class="card-header border-0">
                <h3 class="card-title" style="color:brown">Phân công nhanh</h3>
            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-striped table-valign-middle">
                    <thead>
                        <tr>
                            <?= $available_keyword_header_html; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?= $available_keyword_html;
                        
                          ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>