
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?= base_url(); ?>" class="brand-link">
        <img src="<?= base_url('assets/favicon.png'); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">Trang chủ</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel (optional) -->
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="<?= base_url('assets/user.png'); ?>" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                
                <a href="#" class="d-block"><?=  $username; ?></a>
            </div>
        </div>

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if ($role == 'admin' || $role == 'customer') : ?>
                    <li class="nav-item">
                        <a href="<?= (empty($project)) ? base_url('dashboard') : base_url('dashboard?project_id=' . $project['ID']) ?>" class="nav-link <?php echo ($path == 'dashboard') ? 'active' : ''; ?>">
                            <i class="nav-icon fas fa-tachometer-alt"></i>
                            <p>
                                Dashboard
                            </p>
                        </a>
                    </li>
                    <?php endif; ?>
                     <?php if ($role == 'admin' || $role == 'ctv' || $role == 'customer') : ?>
                    <li class="nav-item">
                        <a href="<?= (empty($project)) ? base_url('keyword') : base_url('keyword?project_id=' . $project['ID']) ?>" class="nav-link <?php echo ($path == 'keyword') ? 'active' : ''; ?>">
                            <i class="nav-icon fa fa-bookmark"></i>
                            <p>Quản lý bài viết</p>
                        </a>
                    </li>
            <?php endif; ?>
              <?php if ($role == 'admin' || $role == 'ctv') : ?>
                    <li class="nav-item">
                        <a href="<?= (empty($project)) ? base_url('keyword-choose') : base_url('keyword-choose?project_id=' . $project['ID']) ?>" class="nav-link <?php echo ($path == 'keyword-choose') ? 'active' : ''; ?>">
                            <i class="nav-icon fa fa-share"></i>
                            <p>Đăng ký từ khóa</p>
                        </a>
                    </li>
                     <hr style="width:100%;text-align:left;margin-left:0">
                    <?php endif; ?>
            <?php if ($role == 'admin' || $role == 'customer') : ?>
                    <li class="nav-item">
                        <a href="<?= base_url('project'); ?>" class="nav-link <?php echo ($path == 'project') ? 'active' : ''; ?>">
                            <i class="nav-icon fas fa-list"></i>
                            <p>
                                Dự án
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if ($role == 'admin') : ?>
                    <li class="nav-item">
                        <a href="<?= base_url('keyword-type'); ?>" class="nav-link <?php echo ($path == 'keyword-type') ? 'active' : ''; ?>">
                            <i class="nav-icon fa fa-cubes"></i>

                            <p>
                                Dạng từ khóa
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
         <?php if ($role == 'admin' || $role == 'ctv') : ?>
                    <li class="nav-item">
                        <a href="<?= base_url('ctv'); ?>" class="nav-link <?php echo ($path == 'ctv') ? 'active' : ''; ?>">

                            <i class="nav-icon fa fa-user"></i>

                            <p>
                                Cộng tác viên
                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if ($role == 'admin') : ?>
                    <li class="nav-item">
                        <a href="<?= base_url('customer'); ?>" class="nav-link <?php echo ($path == 'customer') ? 'active' : ''; ?>">

                            <i class="nav-icon fa fa-user"></i>

                            <p>
                                Khách hàng
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url('ctv_timeline'); ?>" class="nav-link <?php echo ($path == 'ctv_timeline') ? 'active' : ''; ?>">

                            <i class="nav-icon far fa-calendar-alt"></i>

                            <p>
                                Theo dõi CTV
                            </p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url('pay'); ?>" class="nav-link <?php echo ($path == 'pay') ? 'active' : ''; ?>">

                            <i class="nav-icon fa fa-coins"></i>

                            <p>
                                Thống kê nhuận bút
                            </p>
                        </a>
                    </li>
                    
                <?php endif; ?>
                 <?php if ($role == 'admin') : ?>
                    <li class="nav-item">
                        <a href="<?= base_url('pcn'); ?>" class="nav-link">

                           &ensp;<i class="fas fa-fighter-jet"></i>&nbsp;

                            <p>
                                Phân công nhanh
                            </p>
                        </a>
                    </li>
                     <?php endif; ?>
                 <hr style="width:100%;text-align:left;margin-left:0">
             <li class="nav-item">
                     <a href="<?= base_url('logout');?>" class="nav-link">

                           &ensp;<i class="fa fa-share"></i>&nbsp;

                            <p>
                                Đăng xuất
                            </p>
                        </a>
                    </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
 