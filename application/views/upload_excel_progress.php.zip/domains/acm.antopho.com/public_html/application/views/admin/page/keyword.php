<?php
//Trạng thái bài viết
// 0: Đang viết
// 1: Hoàn thành
// 2: Chờ duyệt
// 3: Đã duyệt, chờ thanh toán
// 4: Có góp ý

//Trạng thái outline
// 0: Đang viết
// 1: Đã duyệt outline
// 2: Chờ duyệt outline

                

function update_modal($keyword)
{
    return '<a target="_blank" class="btn btn-primary btn-sm" href="' . base_url('post/update/') . $keyword['ID'] . '">
<i class="fas fa-pencil-alt"></i>
    
</a>';
}

//Keyword đã nhận
$taken_keyword_header_array = ['ID', 'Tên', 'CTV', 'Dạng', 'Dự án', 'Số từ', 'Outline?', 'Nhuận', 'Update lúc','Ngày duyệt', 'Deadline', 'Trạng thái', 'Điểm', '','',''];
$taken_keyword_header_html = '';
foreach ($taken_keyword_header_array as $key => $taken_keyword_header_value) {
    $taken_keyword_header_html .= '<th>' . $taken_keyword_header_value . '</th>';
}
$where_array = ['ctv!=' => null];
if (!empty($project)) {
    $where_array['project'] = $project['ID'];
}

$status = $this->input->get('status');
if (empty($status)) {
    $where_array['finish!='] = 1;
} else {
    switch ($status) {
        case 5:
            $where_array['finish'] = 0;
            break;
        case 2:
            $where_array['finish'] = 2;
            break;
        case 4:
            $where_array['finish'] = 4;
            break;
        case 3:
            $where_array['finish'] = 3;
            break;
        case 1:
            $where_array['finish'] = 1;
            break;
        case 9:
            $where_array['finish'] = 3;
          
            $where_array['posted'] = 1;           
            break;
        case 99:
            $where_array['finish'] = 3;
            
            $where_array['posted'] = 0;           
            break;
         case 19:
            $where_array['finish'] = 2;
          
            $where_array['posted_customer'] = 1;           
            break;
        case 199:
            $where_array['finish'] = 2;
            
            $where_array['posted_customer'] = 0;           
            break;
        case 10:
            $where_array['finish'] = 0;
            $where_array['finish_outline'] = 0;
            $where_array['outline_check'] = 1;
            break;
        case 12:
            $where_array['finish'] = 0;
            $where_array['finish_outline'] = 2;
            $where_array['outline_check'] = 1;
            break;
        case 14:
            $where_array['finish'] = 4;
            $where_array['finish_outline!='] = 1;
            $where_array['outline_check'] = 1;
            break;
    }
}

$taken_keyword_array = result_select('keyword', $where_array, []);
if (!empty($customer_id)) {
    foreach ($taken_keyword_array as $key => $value) {
        $check_project = row_select('project', ['ID' => $value['project']], []);
        if ($check_project['customer'] != $customer_id) {
            unset($taken_keyword_array[$key]);
        }
        if ($value['finish'] != 1 && $value['finish'] != 3 && $value['finish'] != 2 && $value['finish_outline'] != 2 && $value['finish_outline'] = 4) {
            unset($taken_keyword_array[$key]);
        }
    }
}
if ($role == 'ctv') {
    foreach ($taken_keyword_array as $key => $value) {

        if ($value['ctv'] != $ctv_id) {
            unset($taken_keyword_array[$key]);
        }
    }
}
if (empty($status)) {
    foreach ($taken_keyword_array as $key => $value) {
        if ($value['finish'] == 3) {
            unset($taken_keyword_array[$key]);
        }
    }
} else {
    foreach ($taken_keyword_array as $key => $value) {
        switch ($status) {
            case 5:
                if ($value['outline_check'] == 1 && $value['finish_outline'] != 1) {
                    unset($taken_keyword_array[$key]);
                }
                break;
            case 2:
                if ($value['outline_check'] == 1 && $value['finish_outline'] != 1) {
                    unset($taken_keyword_array[$key]);
                }
                break;
            case 4:
                if ($value['outline_check'] == 1 && $value['finish_outline'] != 1) {
                    unset($taken_keyword_array[$key]);
                }
                break;
            case 3:
                if ($value['outline_check'] == 1 && $value['finish_outline'] != 1) {
                    unset($taken_keyword_array[$key]);
                }
                break;
            case 1:
                if ($value['outline_check'] == 1 && $value['finish_outline'] != 1) {
                    unset($taken_keyword_array[$key]);
                }
                break;
        }
    }
}


$taken_keyword_html = '';
foreach ($taken_keyword_array as $key => $taken_keyword_value) {

    $thisType = row_select('keyword_type', ['ID' => $taken_keyword_value['keyword_type']], ['name'])['name'];
    
     $thisType_html = '<option  value="0" selected>'.$thisType.'</option>';
     if (!empty($thisProject)) {
         $this_Type = result_select('keyword_type',[], []);
        foreach ($this_Type as $key => $value){
         $thisType_html .= '<option  value="' . $value['ID'] . '">' . $value['name'] . '</option>';
    }}

    $ctv_info = row_select('users', ['ID' => $taken_keyword_value['ctv']], ['fullname', 'phone']);
    $thisCTV = $ctv_info['fullname'];
    $thisProject = row_select('project', ['ID' => $taken_keyword_value['project']], ['name'])['name'];
    $result_select_html = '<option value="0" selected>'.$thisProject.'</option>';
    if (empty($thisProject)) {
        $result_select_html = '<p style="color:red;">Không tồn tại hoặc đã xóa</p>';
    }else{
        $result_select = result_select('project',[], []);
        foreach ($result_select as $key => $value){
         $result_select_html .= '<option value="' . $value['ID'] . '">' . $value['name'] . '</option>';
    }}
    $thisOutlineCheck = ($taken_keyword_value['outline_check'] == 0) ? 'Không' : 'Có';

    if (!empty($customer_id)) {
        $price = null;
    } else {
        $price_array = row_select('keyword_type_price', ['keyword_type_id' => $taken_keyword_value['keyword_type'], 'word' => $taken_keyword_value['word']], ['price']);

        if (empty($price_array)) {
            $price = '<small style="color:red;">Chưa có mức nhuận cho số từ này</small>';
        } else {
            $price = number_format($price_array['price']);
        }
    }


    $status_text = '';
    $status_color = 'badge-secondary';


    $button_update_html     = update_modal($taken_keyword_value);
    if ($role == 'customer') {
        $button_update_html = '';
    }

    //Trạng thái
    if ($taken_keyword_value['outline_check'] == 0) {
        switch ($taken_keyword_value['finish']) {
            case 0:
                $status_text = 'Đang viết';
                break;
            case 1:
                $status_text = 'Hoàn thành, Đã thanh toán';
                $status_color = 'badge-success';
                break;
            case 2:
                $status_text = 'Chờ duyệt';
                $status_color = 'badge-info';

                break;
            case 3:
                $status_text = 'Đã duyệt, chờ thanh toán';
                $status_color = 'badge-warning';
                break;
            case 4:
                $status_text = 'Có góp ý';
                $status_color = 'badge-danger';
                break;
        }
    } else {
        if ($taken_keyword_value['finish_outline'] == 1 ) {
            switch ($taken_keyword_value['finish']) {
                case 0:
                    $status_text = 'Đã duyệt outline, Đang viết';
                    break;
                case 1:
                    $status_text = 'Hoàn thành, Đã thanh toán';
                    $status_color = 'badge-success';
                    break;
                case 2:
                    $status_text = 'Chờ duyệt';
                    $status_color = 'badge-info';


                    break;
                case 3:
                    $status_text = 'Đã duyệt, chờ thanh toán';
                    $status_color = 'badge-warning';


                    break;
                case 4:
                    $status_text = 'Có góp ý';
                    $status_color = 'badge-danger';
                    break;
            }
        } else {
            switch ($taken_keyword_value['finish_outline']) {
                case 0:
                    $status_text = 'Đang viết outline';
                    break;
                case 2:
                    $status_text    = 'Chờ duyệt outline';
                    $status_color   = 'badge-info';
                    break;
            }
            if ($taken_keyword_value['finish'] == 4) {
                $status_text = 'Có góp ý outline';
                $status_color = 'badge-danger';
            }
        }
    }   
       
       $project_id = $this->input->get('project_id');
        if ($role == 'admin'){
       if($taken_keyword_value['finish'] == 3){
       if($taken_keyword_value['posted'] == 0){
          $posted = '
          
                    <form method="post" action="'.base_url('keyword/posted').'">
                     <input type="hidden" name="ID" value="'. $taken_keyword_value['ID'].'">
                                   <input type="hidden" id="check" name="check" value="1">
                                       <input type="hidden" id="status" name="status" value="'.$status.'">
                                         <input type="hidden" id="project" name="project" value="'. $project_id.'">
                                     <input type="hidden" id="check_page" name="check_page" value="9">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-check"></i>&nbsp; Đăng</button>
                                </form> 
                       ';         
                        

       }else{
            $posted = '
             
                    <form method="post" action="'.base_url('keyword/check_posted').'">
                     <input type="hidden" name="ID" value="'. $taken_keyword_value['ID'].'">
                                   <input type="hidden" id="check" name="check" value="0">
                                       <input type="hidden" id="status" name="status" value="'.$status.'">
                                         <input type="hidden" id="project" name="project" value="'. $project_id.'">
                                     <input type="hidden" id="check_page" name="check_page" value="9">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-reply"></i></i>&nbsp; Hoàn tác </button>
                
                          </form> 
            ';
       }}else{
           $posted = null;
       }}else{
           $posted = null;}


        //    Khách hàng duyệt

 $project_id = $this->input->get('project_id');
        if ($role == 'customer'){
     if($taken_keyword_value['finish'] == 2){
       if($taken_keyword_value['posted_customer'] == 0){
          $posted_customer = '
          
                    <form method="post" action="'.base_url('keyword/posted_customer').'">
                     <input type="hidden" name="ID" value="'. $taken_keyword_value['ID'].'">
                                   <input type="hidden" id="check_customer" name="check_customer" value="1">
                                       <input type="hidden" id="status" name="status" value="'.$status.'">
                                         <input type="hidden" id="project" name="project" value="'. $project_id.'">
                                     <input type="hidden" id="check_page" name="check_page" value="9">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-check"></i>&nbsp; Duyệt</button>
                                </form> 
                       ';         
                        

       }else{
            $posted_customer = '
             
                    <form method="post" action="'.base_url('keyword/check_posted_customer').'">
                     <input type="hidden" name="ID" value="'.$taken_keyword_value['ID'].'">
                                   <input type="hidden" id="check_customer" name="check_customer" value="0">
                                       <input type="hidden" id="status" name="status" value="'.$status.'">
                                         <input type="hidden" id="project" name="project" value="'. $project_id.'">
                                     <input type="hidden" id="check_page" name="check_page" value="9">
                                    <button type="submit"  id="submit" class="btn btn-primary"><i class="fas fa-reply"></i></i>&nbsp; Hoàn tác </button>
                 </form>
                        
            ';
       }}else{
           $posted_customer = null;}}
           else{
           $posted_customer = null;}

  if($taken_keyword_value['finish'] == 2){
   if($taken_keyword_value['posted_customer'] == 1){
   $posted_customer_color = 'posted_color';
   $posted_customer_text  =   'Khác hàng đã duyệt';
                    }else{
                         $posted_customer_color = 'not_posted_color';
                         $posted_customer_text  =  'Khác hàng chưa duyệt';
                    }}else{
                           $posted_customer_color = null;
                             $posted_customer_text = null;

                    };  
              




     if($taken_keyword_value['finish'] == 3){
     if($taken_keyword_value['posted'] == 1){
   $posted_color = 'posted_color';
   $posted_text  =   'Đã đăng';
                    }else{
                         $posted_color = 'not_posted_color';
                         $posted_text  =  'Chưa đăng';
                    }}else{
                           $posted_color = null;
                             $posted_text = null;

                    };   

     if(empty($taken_keyword_value['dateApproveMoney'])){
        $dateApproveMoney = 'Chưa duyệt';
     }else{
        $dateApproveMoney = $taken_keyword_value['dateApproveMoney'];
     }
              
     if ($role == 'admin'){
        $thisTypeRole = '<a href="#noidungcard3'.$taken_keyword_value['ID'].'" aria-expanded="false" data-toggle="collapse">'.$thisType.'</a>
        <div class="card">
        <div class="card-body collapse"  data-toggle="collapse"  aria-expanded="false" id="noidungcard3'.$taken_keyword_value['ID'].'">
             <form method="post" action="'.base_url('keyword/Update_thisType').'">
              <select class="form-control" name="id_thisType" style=" width: 312px" required>
          '.$thisType_html.'
          </select>
                          <input type="hidden" name="check_thisType" value="'.$taken_keyword_value['ID'].'">
                                     <button type="submit" class="btn btn-primary">Cập nhật</button>
                                </form>
        </div>
    
    </div>';
       }else{
        $thisTypeRole = $thisType;
       }

         if ($role == 'admin'){
        $taken_keyword_value_role = ' <a href="#deadline'.$taken_keyword_value['ID'].'" aria-expanded="false" data-toggle="collapse">'.$taken_keyword_value['deadline'].'</a>
                                 <div class="card">
                                   <div class="card-body collapse"  data-toggle="collapse"  aria-expanded="false" id="deadline'.$taken_keyword_value['ID'].'">
                                     <form method="post" action="'.base_url('keyword/Update_deadline').'">
                                       <div class="form-group">
                                        <label for="deadline">Deadline</label>
                                         <input type="datetime-local" class="form-control" id="deadline" name="deadline" required>
                                          </div>
                                           <input type="hidden" name="check_deadline" value="'.$taken_keyword_value['ID'].'">
                                            <button type="submit" class="btn btn-primary">Cập nhật</button>
                                              </form>
                                               </div>   
                                       </div>      ';
       }else{
        $taken_keyword_value_role = $taken_keyword_value['deadline'];
       }



    $taken_keyword_html .= '<tr>
                                    <td>' . $taken_keyword_value['ID'] . '</td>
                                    <td>' . $taken_keyword_value['name'] . '</td>
                                    <td>' . $thisCTV . '<br><small><a target="_blank" href="https://zalo.me/' . $ctv_info['phone'] . '">Zalo</a></small></td>
                                    <td> 
                                     '.$thisTypeRole.'
                                       </td>                     
                                          <td>' . $thisProject . '</td>
                                    <td>' . $taken_keyword_value['word'] . '</td>
                                    <td>' . $thisOutlineCheck . '</td>
                                    <td>' . $price . '</td>                                   
                                    <td>' . $taken_keyword_value['dateUpdate'] . '</td>
                                     <td>' . $dateApproveMoney . '</td>
                                    <td> 
                                     '.$taken_keyword_value_role.'  
                                       </td>
                                    <td style="padding-left: 15px;"><span class="badge ' . $status_color . '">' . $status_text . '</span>
                                    <span class="badge ' .  $posted_color . '">' .  $posted_text . '</span>                                  
                                    <span class="badge ' .  $posted_customer_color . '">' .  $posted_customer_text . '</span>  
                                    </td>
                                    
                                    
                                    <td>' . $taken_keyword_value['point'] . '</td>
                                    <td>'.$posted.'</td>
                                    <td>' . $posted_customer . '</td>
                                    <td>
                                        ' . $button_update_html . '
                                        
                                        <a  target="_blank" class="btn btn-info btn-sm" href="' . base_url('preview/' . $taken_keyword_value['ID']) . '">
                                            <i class="fas fa-eye">
                                            </i>
                                          
                                        </a>   
                                    </td>
                                </tr>';
}
?>
<!-- //Trạng thái bài viết
// 0: Đang viết
// 1: Hoàn thành
// 2: Chờ duyệt
// 3: Đã duyệt, chờ thanh toán
// 4: Có góp ý

//Trạng thái outline
// 0: Đang viết
// 1: Đã duyệt outline
// 2: Chờ duyệt outline -->

 <?php
            $check = $this->input->get('status');
             if(!empty($check)){
            switch ($check) {
            case 0 :
                $status = 'Tất cả';
                break;
            case  5:
                 $status = 'Đang viết';
                 $status_color = '#6c757d';
                break;
            case 2:
                 $status = 'Chờ duyệt';
                  $status_color = '#17a2b8';
                break;
            case 4:
                 $status = 'Có góp ý';
                  $status_color = '#dc3545';
                break;
            case 3:
                 $status = 'Đã duyệt, chờ thanh toán';
                  $status_color = '#ffc107';
                break;
            case 9:
                 $status = 'Đã đăng';
                  $status_color = '#149701';
                break;
                 case 99:
                 $status = 'Chưa đăng';
                  $status_color = '#e73131';
                   case 19:
                 $status = 'khách hàng đã duyệt ';
                  $status_color = '#149701';
                break;
                 case 199:
                 $status = 'khách hàng chưa duyệt';
                  $status_color = '#e73131';
                break;
                 case 1:
                 $status = 'Hoàn thành';
                  $status_color = '#28a745';
                break;
                      case 10:
                        $status = 'Đang viết outline';     
                         $status_color = '#6c757d';   
                break;
                      case 12:
                 $status = 'Chờ duyệt outline';
                  $status_color = '#17a2b8';
                break;
                      case 14:
                 $status = 'Có góp ý outline';
                  $status_color = '#dc3545';
                break;
        }}else{
               $status = 'Trạng thái';
                $status_color = null;

        }
                ?>
<section class="content">
    <div class="container-fluid">
        <div class="mb-2">
             <a class="btn btn-primary dropdown-toggle btn-sm" style="background: <?php echo  $status_color ?>;border-color: <?php echo  $status_color ?>;" href="#" role="button" id="dropdownOrderStatus" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">        
               <?php echo $status ?>           
            </a>
            <div class="dropdown-menu" aria-labelledby="dropdownOrderStatus">
                <?php $all_project_param = (!empty($project)) ? '?project_id=' . $project['ID'] : ''; ?>
                <a class="dropdown-item" href="<?= base_url('keyword' . $all_project_param); ?>">Tất cả</a>
                <?php
               if ($role == 'customer'){
                             $status_array = array(
                    5 => 'Đang viết',
                    2 => 'Chờ duyệt',
                    4 => 'Có góp ý',
                    3 => 'Đã duyệt, chờ thanh toán',
                    9 =>  'Đã đăng',
                    99 =>  'Chưa đăng',
                    19 =>  'Khách hàng đã duyệt',
                    199 =>  'Khách hàng chưa duyệt',
                    1 => 'Hoàn thành',
                    10 => 'Đang viết outline',
                    12 => 'Chờ duyệt outline',
                    14 => 'Có góp ý outline',
                );

               }
                $status_array = array(
                    5 => 'Đang viết',
                    2 => 'Chờ duyệt',
                    4 => 'Có góp ý',
                    3 => 'Đã duyệt, chờ thanh toán',
                    9 =>  'Đã đăng',
                    99 =>  'Chưa đăng',
                    19 =>  'Khách hàng đã duyệt',
                    199 =>  'Khách hàng chưa duyệt',
                    1 => 'Hoàn thành',
                    10 => 'Đang viết outline',
                    12 => 'Chờ duyệt outline',
                    14 => 'Có góp ý outline',
                );

                $project_param = '';
                if (!empty($project)) {
                    $project_param = '&project_id=' . $project['ID'];
                }

                foreach ($status_array as $key => $value) :
                ?>

                    <a class="dropdown-item" href="<?= base_url('keyword?status=' . $key . $project_param); ?>"><?= $value; ?></a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Danh sách bài viết</h3>
            </div>
            <div class="card-body">
                <table class="table table-striped projects datatables table-sm">
                    <thead>
                        <tr>
                            <?= $taken_keyword_header_html; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?= $taken_keyword_html; ?>
                        
                        
                    </tbody>
                    
                </table>
            </div>
        </div>
</section>
 <style>
     .posted_color{
       color: #ffffff;
       background-color: #149701;
         }
         .not_posted_color{
               color: #ffffff;
       background-color: #e73131;

         }
    </style>