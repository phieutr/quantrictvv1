<?php
if(isset($_POST['btn-login'])){
$error = array();
#kiểm tra username
if(empty($_POST['username'])){
  $error['username'] = "Không được để trống tên đăng nhập";
}
#kiểm tra password
if(empty($_POST['password'])){
  $error['password'] = "Không được để trống mật khẩu";
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Đăng nhập</title>
   <link rel="icon" href="<?= base_url('assets/favicon.png') ?>" />
</head>
<body class="hold-transition login-page">
<div class="logo">
<div class="login-box">
  <div class="img"><img style="max-width: 230px;
    
    width: 10p;
    margin-bottom: 26px;
    margin-left: 40px;" src="2.png"></div>
      <form action="<?= base_url('login') ?>" method="post">
    <div class="user-box">
      <input type="text" class="form-control" placeholder="Tên đăng nhập" name="username">
                     
     
    </div>
     <?php
     if(!empty($error['username'])){
   ?>
 
           <p class="error"><?php echo $error['username'] ?></p>
   <?php
   }
    ?> 
    <div class="user-box">
     <input type="password" class="form-control" placeholder="Mật khẩu" name="password">
                        
    </div>
    <div class="password"><?php 

    if(!empty($_SESSION['login_failed'])){
        echo $_SESSION['login_failed'];
    }


?></div>
<div class="error"><?php 

    if(!empty($_SESSION['user_loggedout'])){
        echo $_SESSION['user_loggedout'];
    }


?></div>
     <?php
     
     if(!empty($error['password'])){
   ?>
 
           <p class="error"><?php echo $error['password'] ?></p>
   <?php
   }
    ?> 
    <a href="#">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
       <button type="submit" class="submit" id="btn-login" name="btn-login">ĐĂNG NHẬP</button>
    </a>
  </form>
  <?php
  setcookie('remember_m',true,time()+360000,'/');
  ?>
</div>
</body>
</html>
<style>
.logo{

    background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(2.jpg);
}

html {
  height: 100%;
}
body {
  margin:0;
  padding:0;
  font-family: sans-serif;
  background: linear-gradient(#141e30, #243b55);
}

.login-box {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 400px;
  padding: 40px;
  transform: translate(-50%, -50%);
  background: rgba(0,0,0,.5);
  box-sizing: border-box;
  box-shadow: 0 15px 25px rgba(0,0,0,.6);
  border-radius: 10px;
}

.login-box h2 {
  margin: 0 0 30px;
  padding: 0;
  color: #fff;
  text-align: center;
}

.login-box .user-box {
  position: relative;
}

.login-box .user-box input {
  width: 100%;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background: transparent;
  margin-bottom: 35px;
}
.login-box .user-box label {
  position: absolute;
  top:0;
  left: 0;
  padding: 10px 0;
  font-size: 16px;
  color: #fff;
  pointer-events: none;
  transition: .5s;
}

.login-box .user-box input:focus ~ label,
.login-box .user-box input:valid ~ label {
  top: -20px;
  left: 0;
  color: #03e9f4;
  font-size: 12px;
}

.login-box form a {
  position: relative;
  display: inline-block;

  color: #03e9f4;
  font-size: 16px;
  text-decoration: none;
  text-transform: uppercase;
  overflow: hidden;
  transition: .5s;
  margin-top: 40px;
  letter-spacing: 4px
}

.login-box a:hover {
  background: #03e9f4;
  color: #fff;
  border-radius: 5px;
  box-shadow: 0 0 5px #03e9f4,
              0 0 25px #03e9f4,
              0 0 50px #03e9f4,
              0 0 100px #03e9f4;
}

.login-box a span {
  position: absolute;
  display: block;
}

.login-box a span:nth-child(1) {
  top: 0;
  left: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(90deg, transparent, #03e9f4);
  animation: btn-anim1 1s linear infinite;
}

@keyframes btn-anim1 {
  0% {
    left: -100%;
  }
  50%,100% {
    left: 100%;
  }
}

.login-box a span:nth-child(2) {
  top: -100%;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(180deg, transparent, #03e9f4);
  animation: btn-anim2 1s linear infinite;
  animation-delay: .25s
}

@keyframes btn-anim2 {
  0% {
    top: -100%;
  }
  50%,100% {
    top: 100%;
  }
}

.login-box a span:nth-child(3) {
  bottom: 0;
  right: -100%;
  width: 100%;
  height: 2px;
  background: linear-gradient(270deg, transparent, #03e9f4);
  animation: btn-anim3 1s linear infinite;
  animation-delay: .5s
}

@keyframes btn-anim3 {
  0% {
    right: -100%;
  }
  50%,100% {
    right: 100%;
  }
}

.login-box a span:nth-child(4) {
  bottom: -100%;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(360deg, transparent, #03e9f4);
  animation: btn-anim4 1s linear infinite;
  animation-delay: .75s
}

@keyframes btn-anim4 {
  0% {
    bottom: -100%;
  }
  50%,100% {
    bottom: 100%;
  }
}
.submit{
        background-color: rgb(0 0 0 / 0%);
    color: #9efbff;
    border: none;
        letter-spacing: 2px;
   
    text-transform: uppercase;
    text-decoration: none;
    font-size: 15px;
    padding: 13px;
    width: 320px;
}
.error{
  color:  #9efbff;
}
#img{
        max-width: 230px;
   
    width: 10p;
    margin-bottom: 26px;
    margin-left: 43px;
}
.password{
    color: red;
}
</style>